import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser, hasPermission } from '../auth';

export async function GET(request: NextRequest) {
  const db = (request as any).db;
  const user = await getCurrentUser(db, request);
  
  if (!user) {
    return NextResponse.json(
      { success: false, message: 'Требуется авторизация' },
      { status: 401 }
    );
  }
  
  try {
    const url = new URL(request.url);
    const startDate = url.searchParams.get('startDate');
    const endDate = url.searchParams.get('endDate');
    const reportType = url.searchParams.get('type') || 'revenue';
    
    // Validate parameters
    if (reportType !== 'revenue' && reportType !== 'rentals' && reportType !== 'deposits' && reportType !== 'motorcycles') {
      return NextResponse.json(
        { success: false, message: 'Неверный тип отчета' },
        { status: 400 }
      );
    }
    
    let data;
    
    // Generate report based on type
    switch (reportType) {
      case 'revenue':
        data = await generateRevenueReport(db, startDate, endDate);
        break;
      case 'rentals':
        data = await generateRentalsReport(db, startDate, endDate);
        break;
      case 'deposits':
        data = await generateDepositsReport(db, startDate, endDate);
        break;
      case 'motorcycles':
        data = await generateMotorcyclesReport(db, startDate, endDate);
        break;
    }
    
    return NextResponse.json({
      success: true,
      reportType,
      data
    });
  } catch (error) {
    console.error('Generate report error:', error);
    return NextResponse.json(
      { success: false, message: 'Ошибка при генерации отчета' },
      { status: 500 }
    );
  }
}

async function generateRevenueReport(db: any, startDate: string | null, endDate: string | null) {
  let query = `
    SELECT 
      strftime('%Y-%m', start_date) as month,
      SUM(total_amount) as revenue,
      COUNT(*) as rental_count
    FROM rentals
    WHERE 1=1
  `;
  
  const params: any[] = [];
  
  if (startDate) {
    query += ` AND start_date >= ?`;
    params.push(startDate);
  }
  
  if (endDate) {
    query += ` AND start_date <= ?`;
    params.push(endDate);
  }
  
  query += ` GROUP BY month ORDER BY month`;
  
  const result = await db.prepare(query).bind(...params).all();
  
  // Calculate totals
  const totalRevenue = result.results.reduce((sum: number, item: any) => sum + item.revenue, 0);
  const totalRentals = result.results.reduce((sum: number, item: any) => sum + item.rental_count, 0);
  
  return {
    monthly: result.results,
    total: {
      revenue: totalRevenue,
      rentalCount: totalRentals,
      averageRevenue: totalRentals > 0 ? totalRevenue / totalRentals : 0
    }
  };
}

async function generateRentalsReport(db: any, startDate: string | null, endDate: string | null) {
  let query = `
    SELECT 
      status,
      COUNT(*) as count,
      AVG(julianday(COALESCE(actual_return_date, CURRENT_TIMESTAMP)) - julianday(start_date)) as avg_duration
    FROM rentals
    WHERE 1=1
  `;
  
  const params: any[] = [];
  
  if (startDate) {
    query += ` AND start_date >= ?`;
    params.push(startDate);
  }
  
  if (endDate) {
    query += ` AND start_date <= ?`;
    params.push(endDate);
  }
  
  query += ` GROUP BY status`;
  
  const statusResult = await db.prepare(query).bind(...params).all();
  
  // Get rental types distribution
  let typeQuery = `
    SELECT 
      rental_type,
      COUNT(*) as count
    FROM rentals
    WHERE 1=1
  `;
  
  const typeParams: any[] = [];
  
  if (startDate) {
    typeQuery += ` AND start_date >= ?`;
    typeParams.push(startDate);
  }
  
  if (endDate) {
    typeQuery += ` AND start_date <= ?`;
    typeParams.push(endDate);
  }
  
  typeQuery += ` GROUP BY rental_type`;
  
  const typeResult = await db.prepare(typeQuery).bind(...typeParams).all();
  
  return {
    byStatus: statusResult.results,
    byType: typeResult.results,
    total: {
      count: statusResult.results.reduce((sum: number, item: any) => sum + item.count, 0),
      avgDuration: statusResult.results.reduce((sum: number, item: any) => sum + (item.avg_duration * item.count), 0) / 
                  statusResult.results.reduce((sum: number, item: any) => sum + item.count, 0)
    }
  };
}

async function generateDepositsReport(db: any, startDate: string | null, endDate: string | null) {
  let query = `
    SELECT 
      SUM(deposit_amount) as total_deposits,
      SUM(CASE WHEN deposit_returned = 1 THEN deposit_amount ELSE 0 END) as returned_deposits,
      SUM(CASE WHEN deposit_returned = 0 THEN deposit_amount ELSE 0 END) as held_deposits,
      SUM(deposit_deduction_amount) as deduction_amount,
      COUNT(*) as total_count,
      SUM(CASE WHEN deposit_returned = 1 THEN 1 ELSE 0 END) as returned_count,
      SUM(CASE WHEN deposit_returned = 0 THEN 1 ELSE 0 END) as held_count
    FROM rentals
    WHERE 1=1
  `;
  
  const params: any[] = [];
  
  if (startDate) {
    query += ` AND start_date >= ?`;
    params.push(startDate);
  }
  
  if (endDate) {
    query += ` AND start_date <= ?`;
    params.push(endDate);
  }
  
  const result = await db.prepare(query).bind(...params).first();
  
  // Get deduction reasons
  let reasonsQuery = `
    SELECT 
      deposit_deduction_reason as reason,
      COUNT(*) as count,
      SUM(deposit_deduction_amount) as amount
    FROM rentals
    WHERE deposit_deduction_amount > 0
  `;
  
  const reasonsParams: any[] = [];
  
  if (startDate) {
    reasonsQuery += ` AND start_date >= ?`;
    reasonsParams.push(startDate);
  }
  
  if (endDate) {
    reasonsQuery += ` AND start_date <= ?`;
    reasonsParams.push(endDate);
  }
  
  reasonsQuery += ` GROUP BY deposit_deduction_reason`;
  
  const reasonsResult = await db.prepare(reasonsQuery).bind(...reasonsParams).all();
  
  return {
    summary: result,
    deductionReasons: reasonsResult.results
  };
}

async function generateMotorcyclesReport(db: any, startDate: string | null, endDate: string | null) {
  // Get motorcycle usage statistics
  let query = `
    SELECT 
      m.id, m.brand, m.model, m.license_plate,
      COUNT(r.id) as rental_count,
      SUM(r.total_amount) as revenue,
      SUM(julianday(COALESCE(r.actual_return_date, r.end_date)) - julianday(r.start_date)) as total_days_rented
    FROM motorcycles m
    LEFT JOIN rentals r ON m.id = r.motorcycle_id
  `;
  
  let whereClause = ' WHERE 1=1';
  const params: any[] = [];
  
  if (startDate || endDate) {
    query += whereClause;
    whereClause = ' AND';
    
    if (startDate) {
      query += ` AND r.start_date >= ?`;
      params.push(startDate);
    }
    
    if (endDate) {
      query += ` AND r.start_date <= ?`;
      params.push(endDate);
    }
  }
  
  query += ` GROUP BY m.id ORDER BY rental_count DESC, revenue DESC`;
  
  const result = await db.prepare(query).bind(...params).all();
  
  // Get motorcycle status distribution
  const statusQuery = `
    SELECT status, COUNT(*) as count
    FROM motorcycles
    GROUP BY status
  `;
  
  const statusResult = await db.prepare(statusQuery).all();
  
  return {
    motorcycles: result.results,
    statusDistribution: statusResult.results,
    total: {
      count: result.results.length,
      totalRentals: result.results.reduce((sum: number, item: any) => sum + item.rental_count, 0),
      totalRevenue: result.results.reduce((sum: number, item: any) => sum + item.revenue, 0)
    }
  };
}
