import { D1Database } from '@cloudflare/workers-types';

export interface Motorcycle {
  id: number;
  brand: string;
  model: string;
  license_plate: string;
  year?: number;
  color?: string;
  daily_rate: number;
  weekly_rate: number;
  monthly_rate: number;
  deposit_amount: number;
  status: 'available' | 'rented' | 'maintenance' | 'reserved';
  notes?: string;
  created_at: string;
  updated_at: string;
}

export interface MotorcycleCreateInput {
  brand: string;
  model: string;
  license_plate: string;
  year?: number;
  color?: string;
  daily_rate: number;
  weekly_rate: number;
  monthly_rate: number;
  deposit_amount: number;
  status: 'available' | 'rented' | 'maintenance' | 'reserved';
  notes?: string;
}

export interface MotorcycleUpdateInput {
  brand?: string;
  model?: string;
  license_plate?: string;
  year?: number;
  color?: string;
  daily_rate?: number;
  weekly_rate?: number;
  monthly_rate?: number;
  deposit_amount?: number;
  status?: 'available' | 'rented' | 'maintenance' | 'reserved';
  notes?: string;
}

export interface MotorcycleQueryOptions {
  status?: 'available' | 'rented' | 'maintenance' | 'reserved';
  brand?: string;
  search?: string;
  limit?: number;
  offset?: number;
}

export interface MotorcycleResult {
  success: boolean;
  message: string;
  motorcycle?: Motorcycle;
  motorcycles?: Motorcycle[];
  total?: number;
}

export async function getMotorcycles(
  db: D1Database,
  options: MotorcycleQueryOptions = {}
): Promise<MotorcycleResult> {
  try {
    let query = `
      SELECT id, brand, model, license_plate, year, color, 
             daily_rate, weekly_rate, monthly_rate, deposit_amount, 
             status, notes, created_at, updated_at
      FROM motorcycles
      WHERE 1=1
    `;
    
    const params: any[] = [];
    
    if (options.status) {
      query += ` AND status = ?`;
      params.push(options.status);
    }
    
    if (options.brand) {
      query += ` AND brand = ?`;
      params.push(options.brand);
    }
    
    if (options.search) {
      query += ` AND (brand LIKE ? OR model LIKE ? OR license_plate LIKE ?)`;
      const searchTerm = `%${options.search}%`;
      params.push(searchTerm, searchTerm, searchTerm);
    }
    
    // Get total count
    const countQuery = query.replace(
      'SELECT id, brand, model, license_plate, year, color, \n             daily_rate, weekly_rate, monthly_rate, deposit_amount, \n             status, notes, created_at, updated_at',
      'SELECT COUNT(*) as total'
    );
    
    const countResult = await db.prepare(countQuery).bind(...params).first();
    const total = countResult ? (countResult.total as number) : 0;
    
    // Add sorting and pagination
    query += ` ORDER BY brand ASC, model ASC`;
    
    if (options.limit) {
      query += ` LIMIT ?`;
      params.push(options.limit);
      
      if (options.offset) {
        query += ` OFFSET ?`;
        params.push(options.offset);
      }
    }
    
    const result = await db.prepare(query).bind(...params).all();
    
    return {
      success: true,
      message: 'Мотоциклы успешно получены',
      motorcycles: result.results as Motorcycle[],
      total
    };
  } catch (error) {
    console.error('Get motorcycles error:', error);
    return {
      success: false,
      message: 'Ошибка при получении списка мотоциклов'
    };
  }
}

export async function getMotorcycleById(
  db: D1Database,
  id: number
): Promise<MotorcycleResult> {
  try {
    const result = await db.prepare(`
      SELECT id, brand, model, license_plate, year, color, 
             daily_rate, weekly_rate, monthly_rate, deposit_amount, 
             status, notes, created_at, updated_at
      FROM motorcycles
      WHERE id = ?
    `).bind(id).first();
    
    if (!result) {
      return {
        success: false,
        message: 'Мотоцикл не найден'
      };
    }
    
    return {
      success: true,
      message: 'Мотоцикл успешно получен',
      motorcycle: result as Motorcycle
    };
  } catch (error) {
    console.error('Get motorcycle by ID error:', error);
    return {
      success: false,
      message: 'Ошибка при получении данных мотоцикла'
    };
  }
}

export async function createMotorcycle(
  db: D1Database,
  data: MotorcycleCreateInput
): Promise<MotorcycleResult> {
  try {
    // Check if license plate already exists
    const existingMotorcycle = await db.prepare(
      'SELECT id FROM motorcycles WHERE license_plate = ?'
    ).bind(data.license_plate).first();
    
    if (existingMotorcycle) {
      return {
        success: false,
        message: 'Мотоцикл с таким номером уже существует'
      };
    }
    
    const result = await db.prepare(`
      INSERT INTO motorcycles (
        brand, model, license_plate, year, color,
        daily_rate, weekly_rate, monthly_rate, deposit_amount,
        status, notes
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      data.brand,
      data.model,
      data.license_plate,
      data.year || null,
      data.color || null,
      data.daily_rate,
      data.weekly_rate,
      data.monthly_rate,
      data.deposit_amount,
      data.status,
      data.notes || null
    ).run();
    
    if (!result.success) {
      return {
        success: false,
        message: 'Ошибка при создании мотоцикла'
      };
    }
    
    // Get the created motorcycle
    const createdMotorcycle = await db.prepare(
      'SELECT * FROM motorcycles WHERE license_plate = ?'
    ).bind(data.license_plate).first();
    
    return {
      success: true,
      message: 'Мотоцикл успешно создан',
      motorcycle: createdMotorcycle as Motorcycle
    };
  } catch (error) {
    console.error('Create motorcycle error:', error);
    return {
      success: false,
      message: 'Ошибка при создании мотоцикла'
    };
  }
}

export async function updateMotorcycle(
  db: D1Database,
  id: number,
  data: MotorcycleUpdateInput
): Promise<MotorcycleResult> {
  try {
    // Check if motorcycle exists
    const existingMotorcycle = await db.prepare(
      'SELECT id FROM motorcycles WHERE id = ?'
    ).bind(id).first();
    
    if (!existingMotorcycle) {
      return {
        success: false,
        message: 'Мотоцикл не найден'
      };
    }
    
    // Check if license plate is unique if it's being updated
    if (data.license_plate) {
      const duplicatePlate = await db.prepare(
        'SELECT id FROM motorcycles WHERE license_plate = ? AND id != ?'
      ).bind(data.license_plate, id).first();
      
      if (duplicatePlate) {
        return {
          success: false,
          message: 'Мотоцикл с таким номером уже существует'
        };
      }
    }
    
    // Build update query
    let query = 'UPDATE motorcycles SET ';
    const setClauses: string[] = [];
    const params: any[] = [];
    
    if (data.brand !== undefined) {
      setClauses.push('brand = ?');
      params.push(data.brand);
    }
    
    if (data.model !== undefined) {
      setClauses.push('model = ?');
      params.push(data.model);
    }
    
    if (data.license_plate !== undefined) {
      setClauses.push('license_plate = ?');
      params.push(data.license_plate);
    }
    
    if (data.year !== undefined) {
      setClauses.push('year = ?');
      params.push(data.year);
    }
    
    if (data.color !== undefined) {
      setClauses.push('color = ?');
      params.push(data.color);
    }
    
    if (data.daily_rate !== undefined) {
      setClauses.push('daily_rate = ?');
      params.push(data.daily_rate);
    }
    
    if (data.weekly_rate !== undefined) {
      setClauses.push('weekly_rate = ?');
      params.push(data.weekly_rate);
    }
    
    if (data.monthly_rate !== undefined) {
      setClauses.push('monthly_rate = ?');
      params.push(data.monthly_rate);
    }
    
    if (data.deposit_amount !== undefined) {
      setClauses.push('deposit_amount = ?');
      params.push(data.deposit_amount);
    }
    
    if (data.status !== undefined) {
      setClauses.push('status = ?');
      params.push(data.status);
    }
    
    if (data.notes !== undefined) {
      setClauses.push('notes = ?');
      params.push(data.notes);
    }
    
    setClauses.push('updated_at = CURRENT_TIMESTAMP');
    
    if (setClauses.length === 0) {
      return {
        success: false,
        message: 'Нет данных для обновления'
      };
    }
    
    query += setClauses.join(', ') + ' WHERE id = ?';
    params.push(id);
    
    const result = await db.prepare(query).bind(...params).run();
    
    if (!result.success) {
      return {
        success: false,
        message: 'Ошибка при обновлении мотоцикла'
      };
    }
    
    // Get the updated motorcycle
    const updatedMotorcycle = await db.prepare(
      'SELECT * FROM motorcycles WHERE id = ?'
    ).bind(id).first();
    
    return {
      success: true,
      message: 'Мотоцикл успешно обновлен',
      motorcycle: updatedMotorcycle as Motorcycle
    };
  } catch (error) {
    console.error('Update motorcycle error:', error);
    return {
      success: false,
      message: 'Ошибка при обновлении мотоцикла'
    };
  }
}

export async function deleteMotorcycle(
  db: D1Database,
  id: number
): Promise<MotorcycleResult> {
  try {
    // Check if motorcycle exists
    const existingMotorcycle = await db.prepare(
      'SELECT id, status FROM motorcycles WHERE id = ?'
    ).bind(id).first();
    
    if (!existingMotorcycle) {
      return {
        success: false,
        message: 'Мотоцикл не найден'
      };
    }
    
    // Check if motorcycle is currently rented
    if (existingMotorcycle.status === 'rented') {
      return {
        success: false,
        message: 'Невозможно удалить мотоцикл, который находится в аренде'
      };
    }
    
    // Check if motorcycle has rental history
    const hasRentals = await db.prepare(
      'SELECT COUNT(*) as count FROM rentals WHERE motorcycle_id = ?'
    ).bind(id).first();
    
    if (hasRentals && (hasRentals.count as number) > 0) {
      return {
        success: false,
        message: 'Невозможно удалить мотоцикл с историей аренды'
      };
    }
    
    const result = await db.prepare(
      'DELETE FROM motorcycles WHERE id = ?'
    ).bind(id).run();
    
    if (!result.success) {
      return {
        success: false,
        message: 'Ошибка при удалении мотоцикла'
      };
    }
    
    return {
      success: true,
      message: 'Мотоцикл успешно удален'
    };
  } catch (error) {
    console.error('Delete motorcycle error:', error);
    return {
      success: false,
      message: 'Ошибка при удалении мотоцикла'
    };
  }
}
