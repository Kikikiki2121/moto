import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser, hasPermission } from '../auth';
import nodemailer from 'nodemailer';

export async function POST(request: NextRequest) {
  const db = (request as any).db;
  const user = await getCurrentUser(db, request);
  
  if (!user) {
    return NextResponse.json(
      { success: false, message: 'Требуется авторизация' },
      { status: 401 }
    );
  }
  
  if (!hasPermission(user, 'send_emails')) {
    return NextResponse.json(
      { success: false, message: 'Недостаточно прав для отправки email' },
      { status: 403 }
    );
  }
  
  try {
    const { rentalId, to, subject, body, documentUrl, documentType } = await request.json();
    
    if (!rentalId || !to || !subject || !body) {
      return NextResponse.json(
        { success: false, message: 'Не все обязательные поля заполнены' },
        { status: 400 }
      );
    }
    
    // Get rental data
    const rental = await db.prepare(
      'SELECT id, contract_number FROM rentals WHERE id = ?'
    ).bind(rentalId).first();
    
    if (!rental) {
      return NextResponse.json(
        { success: false, message: 'Аренда не найдена' },
        { status: 404 }
      );
    }
    
    // In a real implementation, you would configure a real email service
    // For now, we'll create a mock transporter
    const transporter = nodemailer.createTransport({
      host: 'smtp.example.com',
      port: 587,
      secure: false,
      auth: {
        user: 'noreply@example.com',
        pass: 'password'
      }
    });
    
    // Prepare email options
    const mailOptions = {
      from: '"МотоРент" <noreply@example.com>',
      to,
      subject,
      text: body,
      attachments: documentUrl ? [
        {
          filename: documentType === 'contract' 
            ? `contract_${rental.contract_number}.pdf` 
            : `invoice_${rental.contract_number}.pdf`,
          path: documentUrl
        }
      ] : []
    };
    
    // In a real implementation, you would send the email
    // For now, we'll just log it and return success
    console.log('Email would be sent with options:', mailOptions);
    
    // Save email record in database
    await db.prepare(`
      INSERT INTO email_logs (rental_id, recipient, subject, body, document_type, sent_by)
      VALUES (?, ?, ?, ?, ?, ?)
    `).bind(
      rentalId,
      to,
      subject,
      body,
      documentType || null,
      user.id
    ).run();
    
    return NextResponse.json({
      success: true,
      message: 'Email успешно отправлен'
    });
  } catch (error) {
    console.error('Send email error:', error);
    return NextResponse.json(
      { success: false, message: 'Ошибка при отправке email' },
      { status: 500 }
    );
  }
}
