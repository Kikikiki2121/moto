'use client';

import { useState, useEffect } from 'react';
import { FiBell, FiCalendar, FiDollarSign, FiTruck, FiUsers, FiPieChart } from 'react-icons/fi';
import { Chart as ChartJS, ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement, Title } from 'chart.js';
import { Pie, Bar } from 'react-chartjs-2';

ChartJS.register(ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement, Title);

export default function Dashboard() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [stats, setStats] = useState({
    activeRentals: 0,
    overdueRentals: 0,
    availableMotorcycles: 0,
    totalClients: 0,
    monthlyRevenue: 0,
    upcomingReturns: 0
  });
  
  const [rentalsByStatus, setRentalsByStatus] = useState({
    active: 0,
    completed: 0,
    overdue: 0,
    cancelled: 0
  });
  
  const [revenueByMonth, setRevenueByMonth] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [upcomingReturns, setUpcomingReturns] = useState([]);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    setLoading(true);
    setError('');

    try {
      // Fetch dashboard statistics
      const statsResponse = await fetch('/api/dashboard/stats');
      const statsData = await statsResponse.json();

      if (statsData.success) {
        setStats(statsData.stats);
        setRentalsByStatus(statsData.rentalsByStatus);
        setRevenueByMonth(statsData.revenueByMonth);
      } else {
        setError(statsData.message || 'Не удалось загрузить статистику');
      }

      // Fetch notifications
      const notificationsResponse = await fetch('/api/notifications?unread=true');
      const notificationsData = await notificationsResponse.json();

      if (notificationsData.success) {
        setNotifications(notificationsData.notifications || []);
      }

      // Fetch upcoming returns
      const returnsResponse = await fetch('/api/rentals?status=active&sort=end_date&limit=5');
      const returnsData = await returnsResponse.json();

      if (returnsData.success) {
        setUpcomingReturns(returnsData.rentals || []);
      }
    } catch (err) {
      setError('Ошибка при загрузке данных');
      console.error('Fetch dashboard data error:', err);
    } finally {
      setLoading(false);
    }
  };

  const pieChartData = {
    labels: ['Активные', 'Завершенные', 'Просроченные', 'Отмененные'],
    datasets: [
      {
        data: [
          rentalsByStatus.active,
          rentalsByStatus.completed,
          rentalsByStatus.overdue,
          rentalsByStatus.cancelled
        ],
        backgroundColor: [
          'rgba(54, 162, 235, 0.6)',
          'rgba(75, 192, 192, 0.6)',
          'rgba(255, 99, 132, 0.6)',
          'rgba(201, 203, 207, 0.6)'
        ],
        borderColor: [
          'rgb(54, 162, 235)',
          'rgb(75, 192, 192)',
          'rgb(255, 99, 132)',
          'rgb(201, 203, 207)'
        ],
        borderWidth: 1,
      },
    ],
  };

  const barChartData = {
    labels: revenueByMonth.map(item => item.month),
    datasets: [
      {
        label: 'Доход (₽)',
        data: revenueByMonth.map(item => item.revenue),
        backgroundColor: 'rgba(75, 192, 192, 0.6)',
        borderColor: 'rgb(75, 192, 192)',
        borderWidth: 1
      }
    ]
  };

  const barChartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
      },
      title: {
        display: true,
        text: 'Доход по месяцам'
      }
    }
  };

  if (loading) {
    return <div className="text-center p-8">Загрузка...</div>;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">Панель управления</h1>
      
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        <div className="bg-white rounded-lg shadow-md p-6 flex items-center">
          <div className="rounded-full bg-blue-100 p-3 mr-4">
            <FiTruck className="text-blue-500 text-xl" />
          </div>
          <div>
            <p className="text-gray-500 text-sm">Активные аренды</p>
            <p className="text-2xl font-semibold">{stats.activeRentals}</p>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6 flex items-center">
          <div className="rounded-full bg-red-100 p-3 mr-4">
            <FiBell className="text-red-500 text-xl" />
          </div>
          <div>
            <p className="text-gray-500 text-sm">Просроченные аренды</p>
            <p className="text-2xl font-semibold">{stats.overdueRentals}</p>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6 flex items-center">
          <div className="rounded-full bg-green-100 p-3 mr-4">
            <FiTruck className="text-green-500 text-xl" />
          </div>
          <div>
            <p className="text-gray-500 text-sm">Доступные мотоциклы</p>
            <p className="text-2xl font-semibold">{stats.availableMotorcycles}</p>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6 flex items-center">
          <div className="rounded-full bg-purple-100 p-3 mr-4">
            <FiUsers className="text-purple-500 text-xl" />
          </div>
          <div>
            <p className="text-gray-500 text-sm">Всего клиентов</p>
            <p className="text-2xl font-semibold">{stats.totalClients}</p>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6 flex items-center">
          <div className="rounded-full bg-yellow-100 p-3 mr-4">
            <FiDollarSign className="text-yellow-500 text-xl" />
          </div>
          <div>
            <p className="text-gray-500 text-sm">Доход за месяц</p>
            <p className="text-2xl font-semibold">{stats.monthlyRevenue} ₽</p>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6 flex items-center">
          <div className="rounded-full bg-blue-100 p-3 mr-4">
            <FiCalendar className="text-blue-500 text-xl" />
          </div>
          <div>
            <p className="text-gray-500 text-sm">Ближайшие возвраты</p>
            <p className="text-2xl font-semibold">{stats.upcomingReturns}</p>
          </div>
        </div>
      </div>
      
      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-lg font-semibold mb-4">Распределение аренд по статусам</h2>
          <div className="h-64">
            <Pie data={pieChartData} />
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-lg font-semibold mb-4">Доход по месяцам</h2>
          <div className="h-64">
            <Bar data={barChartData} options={barChartOptions} />
          </div>
        </div>
      </div>
      
      {/* Notifications and Upcoming Returns */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-lg font-semibold mb-4">Уведомления</h2>
          
          {notifications.length === 0 ? (
            <p className="text-gray-500 italic">Нет новых уведомлений</p>
          ) : (
            <div className="space-y-4">
              {notifications.map((notification: any) => (
                <div key={notification.id} className="border-l-4 border-blue-500 pl-4 py-2">
                  <p className="font-medium">{notification.title}</p>
                  <p className="text-sm text-gray-600">{notification.message}</p>
                  <p className="text-xs text-gray-400 mt-1">
                    {new Date(notification.created_at).toLocaleString()}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-lg font-semibold mb-4">Ближайшие возвраты</h2>
          
          {upcomingReturns.length === 0 ? (
            <p className="text-gray-500 italic">Нет ближайших возвратов</p>
          ) : (
            <div className="space-y-4">
              {upcomingReturns.map((rental: any) => (
                <div key={rental.id} className="flex justify-between border-b pb-2">
                  <div>
                    <p className="font-medium">
                      {rental.client?.full_name || 'Клиент'} - {rental.motorcycle?.brand} {rental.motorcycle?.model}
                    </p>
                    <p className="text-sm text-gray-600">
                      Договор: {rental.contract_number}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium">
                      Дата возврата: {new Date(rental.end_date).toLocaleDateString()}
                    </p>
                    <p className="text-xs text-gray-400">
                      {Math.ceil((new Date(rental.end_date).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))} дней осталось
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
