'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';

type User = {
  id: number;
  username: string;
  full_name: string;
  email: string;
  role: string;
  permissions?: string;
  created_at?: string;
  last_login?: string;
};

export default function UserManagement() {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const router = useRouter();

  // Fetch current user and all users
  useEffect(() => {
    const fetchData = async () => {
      try {
        // Get current user
        const currentUserResponse = await fetch('/api/auth/me');
        if (!currentUserResponse.ok) {
          router.push('/login');
          return;
        }
        
        const currentUserData = await currentUserResponse.json();
        setCurrentUser(currentUserData.user);
        
        // Get all users
        const usersResponse = await fetch('/api/auth/users');
        const usersData = await usersResponse.json();
        
        if (usersData.success) {
          setUsers(usersData.users);
        } else {
          setError(usersData.message || 'Не удалось загрузить пользователей');
        }
      } catch (err) {
        setError('Ошибка при загрузке данных');
        console.error('Fetch error:', err);
      } finally {
        setLoading(false);
      }
    };
    
    fetchData();
  }, [router]);

  // Role display mapping
  const roleDisplay = {
    super_admin: 'Суперадминистратор',
    admin: 'Администратор',
    staff: 'Сотрудник'
  };

  // Check if current user can manage the specified user
  const canManageUser = (user: User) => {
    if (!currentUser) return false;
    
    // Super admin can manage everyone
    if (currentUser.role === 'super_admin') return true;
    
    // Admin can only manage staff
    if (currentUser.role === 'admin' && user.role === 'staff') return true;
    
    return false;
  };

  // Delete user handler
  const handleDeleteUser = async (userId: number) => {
    if (!confirm('Вы уверены, что хотите удалить этого пользователя?')) {
      return;
    }
    
    try {
      const response = await fetch(`/api/auth/users/${userId}`, {
        method: 'DELETE'
      });
      
      const data = await response.json();
      
      if (data.success) {
        // Remove user from list
        setUsers(users.filter(user => user.id !== userId));
      } else {
        setError(data.message || 'Не удалось удалить пользователя');
      }
    } catch (err) {
      setError('Ошибка при удалении пользователя');
      console.error('Delete error:', err);
    }
  };

  if (loading) {
    return <div className="text-center p-8">Загрузка...</div>;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">Управление пользователями</h1>
      
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}
      
      <div className="mb-6">
        <button 
          onClick={() => router.push('/users/new')}
          className="bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 rounded"
        >
          Добавить пользователя
        </button>
      </div>
      
      <div className="overflow-x-auto">
        <table className="min-w-full bg-white border border-gray-200">
          <thead>
            <tr>
              <th className="py-2 px-4 border-b">ID</th>
              <th className="py-2 px-4 border-b">Имя пользователя</th>
              <th className="py-2 px-4 border-b">Полное имя</th>
              <th className="py-2 px-4 border-b">Email</th>
              <th className="py-2 px-4 border-b">Роль</th>
              <th className="py-2 px-4 border-b">Последний вход</th>
              <th className="py-2 px-4 border-b">Действия</th>
            </tr>
          </thead>
          <tbody>
            {users.map(user => (
              <tr key={user.id} className="hover:bg-gray-50">
                <td className="py-2 px-4 border-b">{user.id}</td>
                <td className="py-2 px-4 border-b">{user.username}</td>
                <td className="py-2 px-4 border-b">{user.full_name}</td>
                <td className="py-2 px-4 border-b">{user.email}</td>
                <td className="py-2 px-4 border-b">
                  {roleDisplay[user.role as keyof typeof roleDisplay]}
                </td>
                <td className="py-2 px-4 border-b">
                  {user.last_login ? new Date(user.last_login).toLocaleString() : 'Никогда'}
                </td>
                <td className="py-2 px-4 border-b">
                  {canManageUser(user) && (
                    <div className="flex space-x-2">
                      <button 
                        onClick={() => router.push(`/users/edit/${user.id}`)}
                        className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-1 px-2 rounded text-sm"
                      >
                        Изменить
                      </button>
                      <button 
                        onClick={() => handleDeleteUser(user.id)}
                        className="bg-red-500 hover:bg-red-600 text-white font-bold py-1 px-2 rounded text-sm"
                      >
                        Удалить
                      </button>
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
