'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import DocumentUpload from './DocumentUpload';

type ClientDetailProps = {
  clientId: number;
};

type Client = {
  id: number;
  full_name: string;
  email: string | null;
  phone: string;
  address: string | null;
  passport_number: string;
  passport_issue_date: string | null;
  passport_expiry_date: string | null;
  driver_license_number: string | null;
  driver_license_expiry: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
};

type Document = {
  id: number;
  file_name: string;
  file_path: string;
  document_type: string;
  created_at: string;
};

export default function ClientDetail({ clientId }: ClientDetailProps) {
  const [client, setClient] = useState<Client | null>(null);
  const [documents, setDocuments] = useState<Document[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const router = useRouter();

  useEffect(() => {
    fetchClientData();
  }, [clientId]);

  const fetchClientData = async () => {
    setLoading(true);
    setError('');

    try {
      // Fetch client data
      const clientResponse = await fetch(`/api/clients/${clientId}`);
      const clientData = await clientResponse.json();

      if (clientData.success) {
        setClient(clientData.client);
      } else {
        setError(clientData.message || 'Не удалось загрузить данные клиента');
        return;
      }

      // Fetch client documents
      const documentsResponse = await fetch(`/api/documents?relatedTo=client&relatedId=${clientId}`);
      const documentsData = await documentsResponse.json();

      if (documentsData.success) {
        setDocuments(documentsData.documents || []);
      }
    } catch (err) {
      setError('Ошибка при загрузке данных');
      console.error('Fetch client data error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleDocumentUploadSuccess = (documentId: number, filePath: string) => {
    // Refresh documents list
    fetchClientData();
  };

  if (loading) {
    return <div className="text-center p-8">Загрузка...</div>;
  }

  if (error) {
    return (
      <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
        {error}
      </div>
    );
  }

  if (!client) {
    return <div className="text-center p-8">Клиент не найден</div>;
  }

  // Filter documents by type
  const passportDocuments = documents.filter(doc => doc.document_type === 'passport');
  const driverLicenseDocuments = documents.filter(doc => doc.document_type === 'driver_license');
  const otherDocuments = documents.filter(doc => doc.document_type === 'other');

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">{client.full_name}</h1>
        <div>
          <button
            onClick={() => router.push(`/clients/edit/${client.id}`)}
            className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mr-2"
          >
            Редактировать
          </button>
          <button
            onClick={() => router.push('/clients')}
            className="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded"
          >
            Назад к списку
          </button>
        </div>
      </div>

      <div className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-6">
        <h2 className="text-xl font-semibold mb-4">Основная информация</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          <div>
            <p className="mb-2">
              <span className="font-semibold">ФИО:</span> {client.full_name}
            </p>
            <p className="mb-2">
              <span className="font-semibold">Телефон:</span> {client.phone}
            </p>
            <p className="mb-2">
              <span className="font-semibold">Email:</span> {client.email || '-'}
            </p>
            <p className="mb-2">
              <span className="font-semibold">Адрес:</span> {client.address || '-'}
            </p>
          </div>
          
          <div>
            <p className="mb-2">
              <span className="font-semibold">Номер паспорта:</span> {client.passport_number}
            </p>
            <p className="mb-2">
              <span className="font-semibold">Дата выдачи паспорта:</span> {client.passport_issue_date || '-'}
            </p>
            <p className="mb-2">
              <span className="font-semibold">Срок действия паспорта:</span> {client.passport_expiry_date || '-'}
            </p>
          </div>
        </div>
        
        <div className="mb-6">
          <h3 className="text-lg font-semibold mb-2">Водительское удостоверение</h3>
          <p className="mb-2">
            <span className="font-semibold">Номер:</span> {client.driver_license_number || '-'}
          </p>
          <p className="mb-2">
            <span className="font-semibold">Срок действия:</span> {client.driver_license_expiry || '-'}
          </p>
        </div>
        
        {client.notes && (
          <div className="mb-6">
            <h3 className="text-lg font-semibold mb-2">Примечания</h3>
            <p className="whitespace-pre-line">{client.notes}</p>
          </div>
        )}
      </div>

      <div className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-6">
        <h2 className="text-xl font-semibold mb-4">Документы</h2>
        
        {/* Passport Documents Upload */}
        <DocumentUpload
          relatedTo="client"
          relatedId={client.id}
          documentType="passport"
          onUploadSuccess={handleDocumentUploadSuccess}
          existingDocuments={passportDocuments}
        />
        
        {/* Driver License Documents Upload */}
        <DocumentUpload
          relatedTo="client"
          relatedId={client.id}
          documentType="driver_license"
          onUploadSuccess={handleDocumentUploadSuccess}
          existingDocuments={driverLicenseDocuments}
        />
        
        {/* Other Documents Upload */}
        <DocumentUpload
          relatedTo="client"
          relatedId={client.id}
          documentType="other"
          onUploadSuccess={handleDocumentUploadSuccess}
          existingDocuments={otherDocuments}
        />
      </div>

      <div className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-6">
        <h2 className="text-xl font-semibold mb-4">История аренд</h2>
        
        <button
          onClick={() => router.push(`/rentals/new?clientId=${client.id}`)}
          className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded mb-4"
        >
          Создать новую аренду
        </button>
        
        {/* Rentals history would be loaded and displayed here */}
        <p className="text-gray-500 italic">История аренд будет отображаться здесь</p>
      </div>
    </div>
  );
}
