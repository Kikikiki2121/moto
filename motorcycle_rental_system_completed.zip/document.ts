import { D1Database } from '@cloudflare/workers-types';

export interface Document {
  id: number;
  related_to: 'client' | 'rental';
  related_id: number;
  document_type: 'passport' | 'driver_license' | 'contract' | 'invoice' | 'other';
  file_path: string;
  file_name: string;
  uploaded_by: number;
  created_at: string;
}

export interface DocumentQueryOptions {
  relatedTo?: 'client' | 'rental';
  relatedId?: number;
  documentType?: 'passport' | 'driver_license' | 'contract' | 'invoice' | 'other';
  limit?: number;
  offset?: number;
}

export interface DocumentResult {
  success: boolean;
  message: string;
  document?: Document;
  documents?: Document[];
  total?: number;
}

export async function getDocuments(
  db: D1Database,
  options: DocumentQueryOptions = {}
): Promise<DocumentResult> {
  try {
    let query = `
      SELECT id, related_to, related_id, document_type, file_path, file_name, uploaded_by, created_at
      FROM documents
      WHERE 1=1
    `;
    
    const params: any[] = [];
    
    if (options.relatedTo) {
      query += ` AND related_to = ?`;
      params.push(options.relatedTo);
    }
    
    if (options.relatedId) {
      query += ` AND related_id = ?`;
      params.push(options.relatedId);
    }
    
    if (options.documentType) {
      query += ` AND document_type = ?`;
      params.push(options.documentType);
    }
    
    // Get total count
    const countQuery = query.replace(
      'SELECT id, related_to, related_id, document_type, file_path, file_name, uploaded_by, created_at',
      'SELECT COUNT(*) as total'
    );
    
    const countResult = await db.prepare(countQuery).bind(...params).first();
    const total = countResult ? (countResult.total as number) : 0;
    
    // Add sorting and pagination
    query += ` ORDER BY created_at DESC`;
    
    if (options.limit) {
      query += ` LIMIT ?`;
      params.push(options.limit);
      
      if (options.offset) {
        query += ` OFFSET ?`;
        params.push(options.offset);
      }
    }
    
    const result = await db.prepare(query).bind(...params).all();
    
    return {
      success: true,
      message: 'Документы успешно получены',
      documents: result.results as Document[],
      total
    };
  } catch (error) {
    console.error('Get documents error:', error);
    return {
      success: false,
      message: 'Ошибка при получении списка документов'
    };
  }
}

export async function getDocumentById(
  db: D1Database,
  id: number
): Promise<DocumentResult> {
  try {
    const result = await db.prepare(`
      SELECT id, related_to, related_id, document_type, file_path, file_name, uploaded_by, created_at
      FROM documents
      WHERE id = ?
    `).bind(id).first();
    
    if (!result) {
      return {
        success: false,
        message: 'Документ не найден'
      };
    }
    
    return {
      success: true,
      message: 'Документ успешно получен',
      document: result as Document
    };
  } catch (error) {
    console.error('Get document by ID error:', error);
    return {
      success: false,
      message: 'Ошибка при получении данных документа'
    };
  }
}

export async function deleteDocument(
  db: D1Database,
  id: number
): Promise<DocumentResult> {
  try {
    // Check if document exists
    const existingDocument = await db.prepare(
      'SELECT id FROM documents WHERE id = ?'
    ).bind(id).first();
    
    if (!existingDocument) {
      return {
        success: false,
        message: 'Документ не найден'
      };
    }
    
    const result = await db.prepare(
      'DELETE FROM documents WHERE id = ?'
    ).bind(id).run();
    
    if (!result.success) {
      return {
        success: false,
        message: 'Ошибка при удалении документа'
      };
    }
    
    return {
      success: true,
      message: 'Документ успешно удален'
    };
  } catch (error) {
    console.error('Delete document error:', error);
    return {
      success: false,
      message: 'Ошибка при удалении документа'
    };
  }
}
