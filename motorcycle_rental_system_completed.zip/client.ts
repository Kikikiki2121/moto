import { D1Database } from '@cloudflare/workers-types';

export interface Client {
  id: number;
  full_name: string;
  email: string | null;
  phone: string;
  address: string | null;
  passport_number: string;
  passport_issue_date: string | null;
  passport_expiry_date: string | null;
  driver_license_number: string | null;
  driver_license_expiry: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

export interface ClientCreateInput {
  full_name: string;
  email?: string;
  phone: string;
  address?: string;
  passport_number: string;
  passport_issue_date?: string;
  passport_expiry_date?: string;
  driver_license_number?: string;
  driver_license_expiry?: string;
  notes?: string;
}

export interface ClientUpdateInput {
  full_name?: string;
  email?: string;
  phone?: string;
  address?: string;
  passport_number?: string;
  passport_issue_date?: string;
  passport_expiry_date?: string;
  driver_license_number?: string;
  driver_license_expiry?: string;
  notes?: string;
}

export interface ClientQueryOptions {
  search?: string;
  limit?: number;
  offset?: number;
}

export interface ClientResult {
  success: boolean;
  message: string;
  client?: Client;
  clients?: Client[];
  total?: number;
}

export async function getClients(
  db: D1Database,
  options: ClientQueryOptions = {}
): Promise<ClientResult> {
  try {
    let query = `
      SELECT id, full_name, email, phone, address, 
             passport_number, passport_issue_date, passport_expiry_date,
             driver_license_number, driver_license_expiry,
             notes, created_at, updated_at
      FROM clients
      WHERE 1=1
    `;
    
    const params: any[] = [];
    
    if (options.search) {
      query += ` AND (full_name LIKE ? OR phone LIKE ? OR passport_number LIKE ? OR email LIKE ?)`;
      const searchTerm = `%${options.search}%`;
      params.push(searchTerm, searchTerm, searchTerm, searchTerm);
    }
    
    // Get total count
    const countQuery = query.replace(
      'SELECT id, full_name, email, phone, address, \n             passport_number, passport_issue_date, passport_expiry_date,\n             driver_license_number, driver_license_expiry,\n             notes, created_at, updated_at',
      'SELECT COUNT(*) as total'
    );
    
    const countResult = await db.prepare(countQuery).bind(...params).first();
    const total = countResult ? (countResult.total as number) : 0;
    
    // Add sorting and pagination
    query += ` ORDER BY full_name ASC`;
    
    if (options.limit) {
      query += ` LIMIT ?`;
      params.push(options.limit);
      
      if (options.offset) {
        query += ` OFFSET ?`;
        params.push(options.offset);
      }
    }
    
    const result = await db.prepare(query).bind(...params).all();
    
    return {
      success: true,
      message: 'Клиенты успешно получены',
      clients: result.results as Client[],
      total
    };
  } catch (error) {
    console.error('Get clients error:', error);
    return {
      success: false,
      message: 'Ошибка при получении списка клиентов'
    };
  }
}

export async function getClientById(
  db: D1Database,
  id: number
): Promise<ClientResult> {
  try {
    const result = await db.prepare(`
      SELECT id, full_name, email, phone, address, 
             passport_number, passport_issue_date, passport_expiry_date,
             driver_license_number, driver_license_expiry,
             notes, created_at, updated_at
      FROM clients
      WHERE id = ?
    `).bind(id).first();
    
    if (!result) {
      return {
        success: false,
        message: 'Клиент не найден'
      };
    }
    
    return {
      success: true,
      message: 'Клиент успешно получен',
      client: result as Client
    };
  } catch (error) {
    console.error('Get client by ID error:', error);
    return {
      success: false,
      message: 'Ошибка при получении данных клиента'
    };
  }
}

export async function createClient(
  db: D1Database,
  data: ClientCreateInput
): Promise<ClientResult> {
  try {
    // Check if passport number already exists
    const existingClient = await db.prepare(
      'SELECT id FROM clients WHERE passport_number = ?'
    ).bind(data.passport_number).first();
    
    if (existingClient) {
      return {
        success: false,
        message: 'Клиент с таким номером паспорта уже существует'
      };
    }
    
    const result = await db.prepare(`
      INSERT INTO clients (
        full_name, email, phone, address,
        passport_number, passport_issue_date, passport_expiry_date,
        driver_license_number, driver_license_expiry,
        notes
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      data.full_name,
      data.email || null,
      data.phone,
      data.address || null,
      data.passport_number,
      data.passport_issue_date || null,
      data.passport_expiry_date || null,
      data.driver_license_number || null,
      data.driver_license_expiry || null,
      data.notes || null
    ).run();
    
    if (!result.success) {
      return {
        success: false,
        message: 'Ошибка при создании клиента'
      };
    }
    
    // Get the created client
    const createdClient = await db.prepare(
      'SELECT * FROM clients WHERE passport_number = ?'
    ).bind(data.passport_number).first();
    
    return {
      success: true,
      message: 'Клиент успешно создан',
      client: createdClient as Client
    };
  } catch (error) {
    console.error('Create client error:', error);
    return {
      success: false,
      message: 'Ошибка при создании клиента'
    };
  }
}

export async function updateClient(
  db: D1Database,
  id: number,
  data: ClientUpdateInput
): Promise<ClientResult> {
  try {
    // Check if client exists
    const existingClient = await db.prepare(
      'SELECT id FROM clients WHERE id = ?'
    ).bind(id).first();
    
    if (!existingClient) {
      return {
        success: false,
        message: 'Клиент не найден'
      };
    }
    
    // Check if passport number is unique if it's being updated
    if (data.passport_number) {
      const duplicatePassport = await db.prepare(
        'SELECT id FROM clients WHERE passport_number = ? AND id != ?'
      ).bind(data.passport_number, id).first();
      
      if (duplicatePassport) {
        return {
          success: false,
          message: 'Клиент с таким номером паспорта уже существует'
        };
      }
    }
    
    // Build update query
    let query = 'UPDATE clients SET ';
    const setClauses: string[] = [];
    const params: any[] = [];
    
    if (data.full_name !== undefined) {
      setClauses.push('full_name = ?');
      params.push(data.full_name);
    }
    
    if (data.email !== undefined) {
      setClauses.push('email = ?');
      params.push(data.email || null);
    }
    
    if (data.phone !== undefined) {
      setClauses.push('phone = ?');
      params.push(data.phone);
    }
    
    if (data.address !== undefined) {
      setClauses.push('address = ?');
      params.push(data.address || null);
    }
    
    if (data.passport_number !== undefined) {
      setClauses.push('passport_number = ?');
      params.push(data.passport_number);
    }
    
    if (data.passport_issue_date !== undefined) {
      setClauses.push('passport_issue_date = ?');
      params.push(data.passport_issue_date || null);
    }
    
    if (data.passport_expiry_date !== undefined) {
      setClauses.push('passport_expiry_date = ?');
      params.push(data.passport_expiry_date || null);
    }
    
    if (data.driver_license_number !== undefined) {
      setClauses.push('driver_license_number = ?');
      params.push(data.driver_license_number || null);
    }
    
    if (data.driver_license_expiry !== undefined) {
      setClauses.push('driver_license_expiry = ?');
      params.push(data.driver_license_expiry || null);
    }
    
    if (data.notes !== undefined) {
      setClauses.push('notes = ?');
      params.push(data.notes || null);
    }
    
    setClauses.push('updated_at = CURRENT_TIMESTAMP');
    
    if (setClauses.length === 0) {
      return {
        success: false,
        message: 'Нет данных для обновления'
      };
    }
    
    query += setClauses.join(', ') + ' WHERE id = ?';
    params.push(id);
    
    const result = await db.prepare(query).bind(...params).run();
    
    if (!result.success) {
      return {
        success: false,
        message: 'Ошибка при обновлении клиента'
      };
    }
    
    // Get the updated client
    const updatedClient = await db.prepare(
      'SELECT * FROM clients WHERE id = ?'
    ).bind(id).first();
    
    return {
      success: true,
      message: 'Клиент успешно обновлен',
      client: updatedClient as Client
    };
  } catch (error) {
    console.error('Update client error:', error);
    return {
      success: false,
      message: 'Ошибка при обновлении клиента'
    };
  }
}

export async function deleteClient(
  db: D1Database,
  id: number
): Promise<ClientResult> {
  try {
    // Check if client exists
    const existingClient = await db.prepare(
      'SELECT id FROM clients WHERE id = ?'
    ).bind(id).first();
    
    if (!existingClient) {
      return {
        success: false,
        message: 'Клиент не найден'
      };
    }
    
    // Check if client has rental history
    const hasRentals = await db.prepare(
      'SELECT COUNT(*) as count FROM rentals WHERE client_id = ?'
    ).bind(id).first();
    
    if (hasRentals && (hasRentals.count as number) > 0) {
      return {
        success: false,
        message: 'Невозможно удалить клиента с историей аренды'
      };
    }
    
    const result = await db.prepare(
      'DELETE FROM clients WHERE id = ?'
    ).bind(id).run();
    
    if (!result.success) {
      return {
        success: false,
        message: 'Ошибка при удалении клиента'
      };
    }
    
    return {
      success: true,
      message: 'Клиент успешно удален'
    };
  } catch (error) {
    console.error('Delete client error:', error);
    return {
      success: false,
      message: 'Ошибка при удалении клиента'
    };
  }
}
