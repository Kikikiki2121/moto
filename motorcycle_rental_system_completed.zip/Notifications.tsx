'use client';

import { useState, useEffect } from 'react';
import { FiBell, FiCheck, FiX } from 'react-icons/fi';

interface NotificationsProps {
  userId: number;
  limit?: number;
}

type Notification = {
  id: number;
  title: string;
  message: string;
  related_to: 'rental' | 'client' | 'motorcycle' | 'system';
  related_id: number | null;
  is_read: boolean;
  created_at: string;
};

export default function Notifications({ userId, limit = 5 }: NotificationsProps) {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [unreadCount, setUnreadCount] = useState(0);
  const [showAll, setShowAll] = useState(false);

  useEffect(() => {
    fetchNotifications();
  }, [userId, limit, showAll]);

  const fetchNotifications = async () => {
    setLoading(true);
    setError('');

    try {
      const response = await fetch(`/api/notifications?userId=${userId}&limit=${showAll ? 100 : limit}`);
      const data = await response.json();

      if (data.success) {
        setNotifications(data.notifications || []);
        setUnreadCount(data.notifications.filter((n: Notification) => !n.is_read).length);
      } else {
        setError(data.message || 'Не удалось загрузить уведомления');
      }
    } catch (err) {
      setError('Ошибка при загрузке уведомлений');
      console.error('Fetch notifications error:', err);
    } finally {
      setLoading(false);
    }
  };

  const markAsRead = async (notificationId: number) => {
    try {
      const response = await fetch(`/api/notifications/${notificationId}/read`, {
        method: 'POST',
      });

      const data = await response.json();

      if (data.success) {
        setNotifications(prev => 
          prev.map(n => 
            n.id === notificationId ? { ...n, is_read: true } : n
          )
        );
        setUnreadCount(prev => prev - 1);
      }
    } catch (err) {
      console.error('Mark notification as read error:', err);
    }
  };

  const markAllAsRead = async () => {
    try {
      const response = await fetch(`/api/notifications/read-all`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ userId }),
      });

      const data = await response.json();

      if (data.success) {
        setNotifications(prev => 
          prev.map(n => ({ ...n, is_read: true }))
        );
        setUnreadCount(0);
      }
    } catch (err) {
      console.error('Mark all notifications as read error:', err);
    }
  };

  const getRelatedLink = (notification: Notification) => {
    if (!notification.related_id) return null;

    switch (notification.related_to) {
      case 'rental':
        return `/rentals/${notification.related_id}`;
      case 'client':
        return `/clients/${notification.related_id}`;
      case 'motorcycle':
        return `/motorcycles/${notification.related_id}`;
      default:
        return null;
    }
  };

  if (loading && notifications.length === 0) {
    return <div className="text-center p-4">Загрузка уведомлений...</div>;
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-4">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold flex items-center">
          <FiBell className="mr-2" />
          Уведомления
          {unreadCount > 0 && (
            <span className="ml-2 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full">
              {unreadCount}
            </span>
          )}
        </h2>
        
        {unreadCount > 0 && (
          <button
            onClick={markAllAsRead}
            className="text-sm text-blue-500 hover:text-blue-700"
          >
            Отметить все как прочитанные
          </button>
        )}
      </div>
      
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}
      
      {notifications.length === 0 ? (
        <p className="text-gray-500 italic text-center py-4">Нет уведомлений</p>
      ) : (
        <div className="space-y-3">
          {notifications.map(notification => {
            const relatedLink = getRelatedLink(notification);
            
            return (
              <div 
                key={notification.id} 
                className={`border-l-4 ${notification.is_read ? 'border-gray-300' : 'border-blue-500'} pl-4 py-2 ${!notification.is_read ? 'bg-blue-50' : ''}`}
              >
                <div className="flex justify-between">
                  <h3 className="font-medium">{notification.title}</h3>
                  
                  {!notification.is_read && (
                    <button
                      onClick={() => markAsRead(notification.id)}
                      className="text-gray-500 hover:text-gray-700"
                      title="Отметить как прочитанное"
                    >
                      <FiCheck />
                    </button>
                  )}
                </div>
                
                <p className="text-sm text-gray-600 mt-1">{notification.message}</p>
                
                <div className="flex justify-between items-center mt-2">
                  <span className="text-xs text-gray-400">
                    {new Date(notification.created_at).toLocaleString()}
                  </span>
                  
                  {relatedLink && (
                    <a 
                      href={relatedLink}
                      className="text-xs text-blue-500 hover:text-blue-700"
                    >
                      Перейти
                    </a>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
      
      {!showAll && notifications.length >= limit && (
        <button
          onClick={() => setShowAll(true)}
          className="w-full text-center text-sm text-blue-500 hover:text-blue-700 mt-4"
        >
          Показать все уведомления
        </button>
      )}
      
      {showAll && (
        <button
          onClick={() => setShowAll(false)}
          className="w-full text-center text-sm text-blue-500 hover:text-blue-700 mt-4"
        >
          Показать меньше
        </button>
      )}
    </div>
  );
}
