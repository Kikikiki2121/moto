import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser, hasPermission } from '../auth';
import { PDFDocument, StandardFonts, rgb } from 'pdf-lib';

export async function POST(request: NextRequest) {
  const db = (request as any).db;
  const user = await getCurrentUser(db, request);
  
  if (!user) {
    return NextResponse.json(
      { success: false, message: 'Требуется авторизация' },
      { status: 401 }
    );
  }
  
  if (!hasPermission(user, 'generate_documents')) {
    return NextResponse.json(
      { success: false, message: 'Недостаточно прав для генерации документов' },
      { status: 403 }
    );
  }
  
  try {
    const { rentalId, type } = await request.json();
    
    if (!rentalId || !type) {
      return NextResponse.json(
        { success: false, message: 'Не указан ID аренды или тип документа' },
        { status: 400 }
      );
    }
    
    // Get rental data with client and motorcycle
    const rentalQuery = `
      SELECT r.*, 
             c.full_name as client_name, c.passport_number, c.phone as client_phone, c.email as client_email, c.address as client_address,
             m.brand, m.model, m.license_plate, m.year, m.color
      FROM rentals r
      JOIN clients c ON r.client_id = c.id
      JOIN motorcycles m ON r.motorcycle_id = m.id
      WHERE r.id = ?
    `;
    
    const rental = await db.prepare(rentalQuery).bind(rentalId).first();
    
    if (!rental) {
      return NextResponse.json(
        { success: false, message: 'Аренда не найдена' },
        { status: 404 }
      );
    }
    
    // Generate document based on type
    let documentUrl;
    let documentPath;
    let fileName;
    
    if (type === 'contract') {
      // Generate contract PDF
      const pdfDoc = await PDFDocument.create();
      const page = pdfDoc.addPage([595, 842]); // A4 size
      const font = await pdfDoc.embedFont(StandardFonts.Helvetica);
      const boldFont = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
      
      // Add content to PDF
      page.drawText('ДОГОВОР АРЕНДЫ МОТОЦИКЛА', {
        x: 170,
        y: 800,
        size: 16,
        font: boldFont
      });
      
      page.drawText(`№ ${rental.contract_number}`, {
        x: 250,
        y: 780,
        size: 12,
        font: boldFont
      });
      
      page.drawText(`Дата: ${new Date(rental.created_at).toLocaleDateString()}`, {
        x: 50,
        y: 750,
        size: 12,
        font: font
      });
      
      page.drawText('АРЕНДОДАТЕЛЬ:', {
        x: 50,
        y: 720,
        size: 12,
        font: boldFont
      });
      
      page.drawText('ООО "МотоРент", ИНН 1234567890', {
        x: 50,
        y: 700,
        size: 12,
        font: font
      });
      
      page.drawText('АРЕНДАТОР:', {
        x: 50,
        y: 670,
        size: 12,
        font: boldFont
      });
      
      page.drawText(`${rental.client_name}, Паспорт: ${rental.passport_number}`, {
        x: 50,
        y: 650,
        size: 12,
        font: font
      });
      
      page.drawText(`Адрес: ${rental.client_address || 'Не указан'}`, {
        x: 50,
        y: 630,
        size: 12,
        font: font
      });
      
      page.drawText(`Телефон: ${rental.client_phone}, Email: ${rental.client_email || 'Не указан'}`, {
        x: 50,
        y: 610,
        size: 12,
        font: font
      });
      
      page.drawText('ПРЕДМЕТ АРЕНДЫ:', {
        x: 50,
        y: 580,
        size: 12,
        font: boldFont
      });
      
      page.drawText(`Мотоцикл: ${rental.brand} ${rental.model}, ${rental.year || ''}`, {
        x: 50,
        y: 560,
        size: 12,
        font: font
      });
      
      page.drawText(`Гос. номер: ${rental.license_plate}, Цвет: ${rental.color || 'Не указан'}`, {
        x: 50,
        y: 540,
        size: 12,
        font: font
      });
      
      page.drawText('УСЛОВИЯ АРЕНДЫ:', {
        x: 50,
        y: 510,
        size: 12,
        font: boldFont
      });
      
      page.drawText(`Период аренды: с ${new Date(rental.start_date).toLocaleDateString()} по ${new Date(rental.end_date).toLocaleDateString()}`, {
        x: 50,
        y: 490,
        size: 12,
        font: font
      });
      
      page.drawText(`Тип аренды: ${
        rental.rental_type === 'daily' ? 'Дневная' :
        rental.rental_type === 'weekly' ? 'Недельная' :
        rental.rental_type === 'monthly' ? 'Месячная' : '-'
      }`, {
        x: 50,
        y: 470,
        size: 12,
        font: font
      });
      
      page.drawText(`Тариф: ${rental.rental_rate} ₽ / ${
        rental.rental_type === 'daily' ? 'день' :
        rental.rental_type === 'weekly' ? 'неделя' :
        rental.rental_type === 'monthly' ? 'месяц' : '-'
      }`, {
        x: 50,
        y: 450,
        size: 12,
        font: font
      });
      
      page.drawText('ПЛАТЕЖИ:', {
        x: 50,
        y: 420,
        size: 12,
        font: boldFont
      });
      
      page.drawText(`Стоимость аренды: ${rental.total_amount} ₽`, {
        x: 50,
        y: 400,
        size: 12,
        font: font
      });
      
      page.drawText(`Депозит: ${rental.deposit_amount} ₽`, {
        x: 50,
        y: 380,
        size: 12,
        font: font
      });
      
      page.drawText(`Итого к оплате: ${rental.total_amount + rental.deposit_amount} ₽`, {
        x: 50,
        y: 360,
        size: 12,
        font: boldFont
      });
      
      page.drawText('ПОДПИСИ СТОРОН:', {
        x: 50,
        y: 300,
        size: 12,
        font: boldFont
      });
      
      page.drawText('Арендодатель: ________________', {
        x: 50,
        y: 270,
        size: 12,
        font: font
      });
      
      page.drawText('Арендатор: ________________', {
        x: 50,
        y: 240,
        size: 12,
        font: font
      });
      
      // Save PDF
      const pdfBytes = await pdfDoc.save();
      
      // In a real implementation, you would save the file to storage
      // For now, we'll just return a mock URL
      fileName = `contract_${rental.contract_number}.pdf`;
      documentPath = `/uploads/contracts/${fileName}`;
      documentUrl = `/api/documents/download?path=${encodeURIComponent(documentPath)}`;
      
      // Save document record in database
      await db.prepare(`
        INSERT INTO documents (related_to, related_id, document_type, file_path, file_name, uploaded_by)
        VALUES (?, ?, ?, ?, ?, ?)
      `).bind(
        'rental',
        rentalId,
        'contract',
        documentPath,
        fileName,
        user.id
      ).run();
      
    } else if (type === 'invoice') {
      // Generate invoice PDF
      const pdfDoc = await PDFDocument.create();
      const page = pdfDoc.addPage([595, 842]); // A4 size
      const font = await pdfDoc.embedFont(StandardFonts.Helvetica);
      const boldFont = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
      
      // Add content to PDF
      page.drawText('СЧЕТ НА ОПЛАТУ', {
        x: 230,
        y: 800,
        size: 16,
        font: boldFont
      });
      
      page.drawText(`№ ${rental.contract_number}-INV`, {
        x: 250,
        y: 780,
        size: 12,
        font: boldFont
      });
      
      page.drawText(`Дата: ${new Date(rental.created_at).toLocaleDateString()}`, {
        x: 50,
        y: 750,
        size: 12,
        font: font
      });
      
      page.drawText('ПОСТАВЩИК:', {
        x: 50,
        y: 720,
        size: 12,
        font: boldFont
      });
      
      page.drawText('ООО "МотоРент", ИНН 1234567890', {
        x: 50,
        y: 700,
        size: 12,
        font: font
      });
      
      page.drawText('ПЛАТЕЛЬЩИК:', {
        x: 50,
        y: 670,
        size: 12,
        font: boldFont
      });
      
      page.drawText(`${rental.client_name}, Паспорт: ${rental.passport_number}`, {
        x: 50,
        y: 650,
        size: 12,
        font: font
      });
      
      page.drawText(`Адрес: ${rental.client_address || 'Не указан'}`, {
        x: 50,
        y: 630,
        size: 12,
        font: font
      });
      
      page.drawText('УСЛУГИ:', {
        x: 50,
        y: 580,
        size: 12,
        font: boldFont
      });
      
      // Draw table header
      page.drawRectangle({
        x: 50,
        y: 560,
        width: 500,
        height: 20,
        color: rgb(0.9, 0.9, 0.9),
      });
      
      page.drawText('№', {
        x: 60,
        y: 565,
        size: 10,
        font: boldFont
      });
      
      page.drawText('Наименование', {
        x: 100,
        y: 565,
        size: 10,
        font: boldFont
      });
      
      page.drawText('Период', {
        x: 300,
        y: 565,
        size: 10,
        font: boldFont
      });
      
      page.drawText('Сумма', {
        x: 480,
        y: 565,
        size: 10,
        font: boldFont
      });
      
      // Draw table row 1
      page.drawText('1', {
        x: 60,
        y: 540,
        size: 10,
        font: font
      });
      
      page.drawText(`Аренда мотоцикла ${rental.brand} ${rental.model} (${rental.license_plate})`, {
        x: 100,
        y: 540,
        size: 10,
        font: font
      });
      
      page.drawText(`${new Date(rental.start_date).toLocaleDateString()} - ${new Date(rental.end_date).toLocaleDateString()}`, {
        x: 300,
        y: 540,
        size: 10,
        font: font
      });
      
      page.drawText(`${rental.total_amount} ₽`, {
        x: 480,
        y: 540,
        size: 10,
        font: font
      });
      
      // Draw table row 2
      page.drawText('2', {
        x: 60,
        y: 520,
        size: 10,
        font: font
      });
      
      page.drawText('Депозит (возвратный)', {
        x: 100,
        y: 520,
        size: 10,
        font: font
      });
      
      page.drawText('-', {
        x: 300,
        y: 520,
        size: 10,
        font: font
      });
      
      page.drawText(`${rental.deposit_amount} ₽`, {
        x: 480,
        y: 520,
        size: 10,
        font: font
      });
      
      // Draw total
      page.drawLine({
        start: { x: 50, y: 500 },
        end: { x: 550, y: 500 },
        thickness: 1,
        color: rgb(0, 0, 0),
      });
      
      page.drawText('Итого к оплате:', {
        x: 380,
        y: 480,
        size: 12,
        font: boldFont
      });
      
      page.drawText(`${rental.total_amount + rental.deposit_amount} ₽`, {
        x: 480,
        y: 480,
        size: 12,
        font: boldFont
      });
      
      page.drawText('Реквизиты для оплаты:', {
        x: 50,
        y: 440,
        size: 12,
        font: boldFont
      });
      
      page.drawText('ООО "МотоРент"', {
        x: 50,
        y: 420,
        size: 10,
        font: font
      });
      
      page.drawText('ИНН: 1234567890', {
        x: 50,
        y: 400,
        size: 10,
        font: font
      });
      
      page.drawText('Р/с: 40702810123456789012 в Банке "Пример"', {
        x: 50,
        y: 380,
        size: 10,
        font: font
      });
      
      page.drawText('БИК: 044525123', {
        x: 50,
        y: 360,
        size: 10,
        font: font
      });
      
      page.drawText('К/с: 30101810400000000123', {
        x: 50,
        y: 340,
        size: 10,
        font: font
      });
      
      // Save PDF
      const pdfBytes = await pdfDoc.save();
      
      // In a real implementation, you would save the file to storage
      // For now, we'll just return a mock URL
      fileName = `invoice_${rental.contract_number}.pdf`;
      documentPath = `/uploads/invoices/${fileName}`;
      documentUrl = `/api/documents/download?path=${encodeURIComponent(documentPath)}`;
      
      // Save document record in database
      await db.prepare(`
        INSERT INTO documents (related_to, related_id, document_type, file_path, file_name, uploaded_by)
        VALUES (?, ?, ?, ?, ?, ?)
      `).bind(
        'rental',
        rentalId,
        'invoice',
        documentPath,
        fileName,
        user.id
      ).run();
    } else {
      return NextResponse.json(
        { success: false, message: 'Неподдерживаемый тип документа' },
        { status: 400 }
      );
    }
    
    return NextResponse.json({
      success: true,
      message: `${type === 'contract' ? 'Договор' : 'Счет'} успешно сгенерирован`,
      documentUrl,
      documentPath,
      fileName
    });
  } catch (error) {
    console.error('Generate document error:', error);
    return NextResponse.json(
      { success: false, message: 'Ошибка при генерации документа' },
      { status: 500 }
    );
  }
}
