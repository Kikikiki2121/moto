'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';

type RentalFormProps = {
  motorcycleId?: number;
  clientId?: number;
};

type Motorcycle = {
  id: number;
  brand: string;
  model: string;
  license_plate: string;
  daily_rate: number;
  weekly_rate: number;
  monthly_rate: number;
  deposit_amount: number;
  status: string;
};

type Client = {
  id: number;
  full_name: string;
  phone: string;
  passport_number: string;
};

type RentalFormData = {
  motorcycle_id: number;
  client_id: number;
  start_date: string;
  end_date: string;
  rental_type: 'daily' | 'weekly' | 'monthly';
  rental_rate: number;
  total_amount: number;
  deposit_amount: number;
  notes: string;
};

export default function RentalCalculator({ motorcycleId, clientId }: RentalFormProps) {
  const [motorcycles, setMotorcycles] = useState<Motorcycle[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [calculating, setCalculating] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const router = useRouter();

  const [formData, setFormData] = useState<RentalFormData>({
    motorcycle_id: motorcycleId || 0,
    client_id: clientId || 0,
    start_date: new Date().toISOString().split('T')[0],
    end_date: new Date(Date.now() + 86400000).toISOString().split('T')[0], // tomorrow
    rental_type: 'daily',
    rental_rate: 0,
    total_amount: 0,
    deposit_amount: 0,
    notes: ''
  });

  const [selectedMotorcycle, setSelectedMotorcycle] = useState<Motorcycle | null>(null);
  const [days, setDays] = useState(1);

  useEffect(() => {
    Promise.all([
      fetchMotorcycles(),
      fetchClients()
    ]).then(() => {
      setLoading(false);
      if (motorcycleId || clientId) {
        calculateRental();
      }
    });
  }, []);

  useEffect(() => {
    if (formData.motorcycle_id && motorcycles.length > 0) {
      const motorcycle = motorcycles.find(m => m.id === formData.motorcycle_id);
      setSelectedMotorcycle(motorcycle || null);
      
      if (motorcycle) {
        setFormData(prev => ({
          ...prev,
          deposit_amount: motorcycle.deposit_amount
        }));
      }
    }
  }, [formData.motorcycle_id, motorcycles]);

  useEffect(() => {
    if (formData.start_date && formData.end_date) {
      const start = new Date(formData.start_date);
      const end = new Date(formData.end_date);
      const diffTime = Math.abs(end.getTime() - start.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      setDays(diffDays);
    }
  }, [formData.start_date, formData.end_date]);

  const fetchMotorcycles = async () => {
    try {
      const response = await fetch('/api/motorcycles?status=available');
      const data = await response.json();

      if (data.success) {
        setMotorcycles(data.motorcycles || []);
      } else {
        setError(data.message || 'Не удалось загрузить список мотоциклов');
      }
    } catch (err) {
      setError('Ошибка при загрузке данных мотоциклов');
      console.error('Fetch motorcycles error:', err);
    }
  };

  const fetchClients = async () => {
    try {
      const response = await fetch('/api/clients');
      const data = await response.json();

      if (data.success) {
        setClients(data.clients || []);
      } else {
        setError(data.message || 'Не удалось загрузить список клиентов');
      }
    } catch (err) {
      setError('Ошибка при загрузке данных клиентов');
      console.error('Fetch clients error:', err);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));

    // Recalculate when dates or motorcycle changes
    if (['start_date', 'end_date', 'motorcycle_id'].includes(name)) {
      calculateRental();
    }
  };

  const calculateRental = () => {
    if (!formData.motorcycle_id || !formData.start_date || !formData.end_date) {
      return;
    }

    setCalculating(true);
    setError('');

    try {
      const motorcycle = motorcycles.find(m => m.id === formData.motorcycle_id);
      
      if (!motorcycle) {
        setError('Мотоцикл не найден');
        setCalculating(false);
        return;
      }

      const start = new Date(formData.start_date);
      const end = new Date(formData.end_date);
      
      if (start >= end) {
        setError('Дата окончания должна быть позже даты начала');
        setCalculating(false);
        return;
      }

      const diffTime = Math.abs(end.getTime() - start.getTime());
      const days = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      setDays(days);

      let rentalType: 'daily' | 'weekly' | 'monthly';
      let rentalRate: number;
      let totalAmount: number;

      // Determine rental type and rate based on duration
      if (days >= 30) {
        const months = Math.floor(days / 30);
        const remainingDays = days % 30;
        
        rentalType = 'monthly';
        rentalRate = motorcycle.monthly_rate;
        totalAmount = (months * motorcycle.monthly_rate) + 
                      (remainingDays * (motorcycle.daily_rate * 0.9)); // 10% discount for remaining days
      } else if (days >= 7) {
        const weeks = Math.floor(days / 7);
        const remainingDays = days % 7;
        
        rentalType = 'weekly';
        rentalRate = motorcycle.weekly_rate;
        totalAmount = (weeks * motorcycle.weekly_rate) + 
                      (remainingDays * (motorcycle.daily_rate * 0.9)); // 10% discount for remaining days
      } else {
        rentalType = 'daily';
        rentalRate = motorcycle.daily_rate;
        totalAmount = days * motorcycle.daily_rate;
      }

      setFormData(prev => ({
        ...prev,
        rental_type: rentalType,
        rental_rate: rentalRate,
        total_amount: totalAmount,
        deposit_amount: motorcycle.deposit_amount
      }));

    } catch (err) {
      setError('Ошибка при расчете стоимости аренды');
      console.error('Calculate rental error:', err);
    } finally {
      setCalculating(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!formData.motorcycle_id || !formData.client_id || !formData.start_date || !formData.end_date) {
      setError('Заполните все обязательные поля');
      return;
    }

    try {
      const response = await fetch('/api/rentals', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (data.success) {
        setSuccess(data.message || 'Аренда успешно создана');
        
        // Redirect to rental detail page after a short delay
        setTimeout(() => {
          router.push(`/rentals/${data.rental.id}`);
        }, 2000);
      } else {
        setError(data.message || 'Произошла ошибка при создании аренды');
      }
    } catch (err) {
      setError('Произошла ошибка при отправке данных');
      console.error('Submit error:', err);
    }
  };

  if (loading) {
    return <div className="text-center p-8">Загрузка...</div>;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">Расчет стоимости аренды</h1>
      
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}
      
      {success && (
        <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
          {success}
        </div>
      )}
      
      <form onSubmit={handleSubmit} className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="motorcycle_id">
              Мотоцикл *
            </label>
            <select
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              id="motorcycle_id"
              name="motorcycle_id"
              value={formData.motorcycle_id}
              onChange={handleChange}
              required
            >
              <option value="">Выберите мотоцикл</option>
              {motorcycles.map(motorcycle => (
                <option key={motorcycle.id} value={motorcycle.id}>
                  {motorcycle.brand} {motorcycle.model} ({motorcycle.license_plate})
                </option>
              ))}
            </select>
          </div>
          
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="client_id">
              Клиент *
            </label>
            <select
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              id="client_id"
              name="client_id"
              value={formData.client_id}
              onChange={handleChange}
              required
            >
              <option value="">Выберите клиента</option>
              {clients.map(client => (
                <option key={client.id} value={client.id}>
                  {client.full_name} ({client.passport_number})
                </option>
              ))}
            </select>
          </div>
          
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="start_date">
              Дата начала *
            </label>
            <input
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              id="start_date"
              type="date"
              name="start_date"
              value={formData.start_date}
              onChange={handleChange}
              required
            />
          </div>
          
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="end_date">
              Дата окончания *
            </label>
            <input
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              id="end_date"
              type="date"
              name="end_date"
              value={formData.end_date}
              onChange={handleChange}
              required
            />
          </div>
        </div>
        
        <div className="mb-6">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="notes">
            Примечания
          </label>
          <textarea
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            id="notes"
            name="notes"
            value={formData.notes}
            onChange={handleChange}
            rows={3}
          />
        </div>
        
        <div className="bg-gray-100 p-4 rounded-md mb-6">
          <h2 className="text-lg font-semibold mb-3">Расчет стоимости</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <p className="mb-2">
                <span className="font-semibold">Период аренды:</span> {days} {days === 1 ? 'день' : days < 5 ? 'дня' : 'дней'}
              </p>
              <p className="mb-2">
                <span className="font-semibold">Тип аренды:</span> {
                  formData.rental_type === 'daily' ? 'Дневная' :
                  formData.rental_type === 'weekly' ? 'Недельная' :
                  formData.rental_type === 'monthly' ? 'Месячная' : '-'
                }
              </p>
              <p className="mb-2">
                <span className="font-semibold">Тариф:</span> {formData.rental_rate} ₽ / {
                  formData.rental_type === 'daily' ? 'день' :
                  formData.rental_type === 'weekly' ? 'неделя' :
                  formData.rental_type === 'monthly' ? 'месяц' : '-'
                }
              </p>
            </div>
            
            <div>
              <p className="mb-2">
                <span className="font-semibold">Стоимость аренды:</span> {formData.total_amount} ₽
              </p>
              <p className="mb-2">
                <span className="font-semibold">Депозит:</span> {formData.deposit_amount} ₽
              </p>
              <p className="mb-2">
                <span className="font-semibold">Итого к оплате:</span> {formData.total_amount + formData.deposit_amount} ₽
              </p>
            </div>
          </div>
          
          <button
            type="button"
            onClick={calculateRental}
            className="mt-3 bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
            disabled={calculating}
          >
            {calculating ? 'Расчет...' : 'Пересчитать'}
          </button>
        </div>
        
        <div className="flex items-center justify-between">
          <button
            className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
            type="submit"
          >
            Создать аренду и договор
          </button>
          <button
            className="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
            type="button"
            onClick={() => router.push('/rentals')}
          >
            Отмена
          </button>
        </div>
      </form>
    </div>
  );
}
