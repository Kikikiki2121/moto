import { NextRequest, NextResponse } from 'next/server';
import { env } from 'process';
import { getCurrentUser, hasPermission } from './auth';

export async function GET(
  request: NextRequest,
  { params }: { params: { slug: string[] } }
) {
  const db = (request as any).db;
  const user = await getCurrentUser(db, request);
  
  if (!user) {
    return NextResponse.json(
      { success: false, message: 'Требуется авторизация' },
      { status: 401 }
    );
  }
  
  // Handle specific API routes
  const slug = params.slug || [];
  
  // Add route for document download
  if (slug[0] === 'documents' && slug[1] === 'download') {
    if (!hasPermission(user, 'view_documents')) {
      return NextResponse.json(
        { success: false, message: 'Недостаточно прав для просмотра документов' },
        { status: 403 }
      );
    }
    
    const url = new URL(request.url);
    const filePath = url.searchParams.get('path');
    
    if (!filePath) {
      return NextResponse.json(
        { success: false, message: 'Не указан путь к файлу' },
        { status: 400 }
      );
    }
    
    // In a real implementation, you would validate the file path and serve the file
    // For now, we'll just return a mock response
    return NextResponse.json(
      { success: true, message: 'Файл готов к скачиванию', file_path: filePath },
      { status: 200 }
    );
  }
  
  return NextResponse.json(
    { success: false, message: 'Маршрут не найден' },
    { status: 404 }
  );
}

export async function POST(
  request: NextRequest,
  { params }: { params: { slug: string[] } }
) {
  const db = (request as any).db;
  const user = await getCurrentUser(db, request);
  
  if (!user) {
    return NextResponse.json(
      { success: false, message: 'Требуется авторизация' },
      { status: 401 }
    );
  }
  
  // Handle specific API routes
  const slug = params.slug || [];
  
  // Add route for document upload
  if (slug[0] === 'documents' && slug[1] === 'upload') {
    if (!hasPermission(user, 'upload_documents')) {
      return NextResponse.json(
        { success: false, message: 'Недостаточно прав для загрузки документов' },
        { status: 403 }
      );
    }
    
    try {
      const formData = await request.formData();
      const file = formData.get('file') as File;
      const relatedTo = formData.get('relatedTo') as string;
      const relatedId = parseInt(formData.get('relatedId') as string);
      const documentType = formData.get('documentType') as string;
      
      if (!file || !relatedTo || !relatedId || !documentType) {
        return NextResponse.json(
          { success: false, message: 'Не все обязательные поля заполнены' },
          { status: 400 }
        );
      }
      
      // Validate file type
      const allowedTypes = ['application/pdf', 'image/jpeg', 'image/png'];
      if (!allowedTypes.includes(file.type)) {
        return NextResponse.json(
          { success: false, message: 'Неподдерживаемый тип файла. Разрешены только PDF, JPG и PNG' },
          { status: 400 }
        );
      }
      
      // Validate file size (max 5MB)
      const maxSize = 5 * 1024 * 1024; // 5MB
      if (file.size > maxSize) {
        return NextResponse.json(
          { success: false, message: 'Размер файла превышает максимально допустимый (5MB)' },
          { status: 400 }
        );
      }
      
      // In a real implementation, you would save the file to storage and create a record in the database
      // For now, we'll just return a mock response
      const fileName = file.name;
      const filePath = `/uploads/${relatedTo}/${relatedId}/${documentType}/${fileName}`;
      
      // Insert document record in database
      const result = await db.prepare(`
        INSERT INTO documents (related_to, related_id, document_type, file_path, file_name, uploaded_by)
        VALUES (?, ?, ?, ?, ?, ?)
      `).bind(
        relatedTo,
        relatedId,
        documentType,
        filePath,
        fileName,
        user.id
      ).run();
      
      if (!result.success) {
        return NextResponse.json(
          { success: false, message: 'Ошибка при сохранении информации о документе' },
          { status: 500 }
        );
      }
      
      // Get the created document
      const documentId = result.meta?.last_row_id || 0;
      const document = await db.prepare(
        'SELECT * FROM documents WHERE id = ?'
      ).bind(documentId).first();
      
      return NextResponse.json({
        success: true,
        message: 'Документ успешно загружен',
        document: {
          id: document.id,
          file_name: document.file_name,
          file_path: document.file_path,
          created_at: document.created_at
        }
      });
    } catch (error) {
      console.error('Document upload error:', error);
      return NextResponse.json(
        { success: false, message: 'Ошибка при загрузке документа' },
        { status: 500 }
      );
    }
  }
  
  return NextResponse.json(
    { success: false, message: 'Маршрут не найден' },
    { status: 404 }
  );
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { slug: string[] } }
) {
  const db = (request as any).db;
  const user = await getCurrentUser(db, request);
  
  if (!user) {
    return NextResponse.json(
      { success: false, message: 'Требуется авторизация' },
      { status: 401 }
    );
  }
  
  // Handle specific API routes
  const slug = params.slug || [];
  
  // Add route for document deletion
  if (slug[0] === 'documents' && slug[1]) {
    if (!hasPermission(user, 'delete_documents')) {
      return NextResponse.json(
        { success: false, message: 'Недостаточно прав для удаления документов' },
        { status: 403 }
      );
    }
    
    const documentId = parseInt(slug[1]);
    
    if (isNaN(documentId)) {
      return NextResponse.json(
        { success: false, message: 'Неверный идентификатор документа' },
        { status: 400 }
      );
    }
    
    try {
      // Check if document exists
      const document = await db.prepare(
        'SELECT * FROM documents WHERE id = ?'
      ).bind(documentId).first();
      
      if (!document) {
        return NextResponse.json(
          { success: false, message: 'Документ не найден' },
          { status: 404 }
        );
      }
      
      // In a real implementation, you would delete the file from storage
      
      // Delete document record from database
      const result = await db.prepare(
        'DELETE FROM documents WHERE id = ?'
      ).bind(documentId).run();
      
      if (!result.success) {
        return NextResponse.json(
          { success: false, message: 'Ошибка при удалении документа' },
          { status: 500 }
        );
      }
      
      return NextResponse.json({
        success: true,
        message: 'Документ успешно удален'
      });
    } catch (error) {
      console.error('Document delete error:', error);
      return NextResponse.json(
        { success: false, message: 'Ошибка при удалении документа' },
        { status: 500 }
      );
    }
  }
  
  return NextResponse.json(
    { success: false, message: 'Маршрут не найден' },
    { status: 404 }
  );
}
