import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { verifyToken } from './lib/auth/auth';

// Define which paths should be protected
const protectedPaths = [
  '/dashboard',
  '/users',
  '/motorcycles',
  '/clients',
  '/rentals',
  '/reports',
];

// Define which paths should be redirected if user is already authenticated
const authPaths = [
  '/login',
];

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;
  
  // Get token from cookies
  const token = request.cookies.get('auth_token')?.value;
  
  // Check if user is authenticated
  const isAuthenticated = token && await verifyToken(token);
  
  // Handle protected routes
  if (protectedPaths.some(path => pathname.startsWith(path))) {
    if (!isAuthenticated) {
      const url = new URL('/login', request.url);
      url.searchParams.set('redirect', pathname);
      return NextResponse.redirect(url);
    }
  }
  
  // Handle auth routes (redirect to dashboard if already logged in)
  if (authPaths.some(path => pathname.startsWith(path))) {
    if (isAuthenticated) {
      return NextResponse.redirect(new URL('/dashboard', request.url));
    }
  }
  
  // If root path and authenticated, redirect to dashboard
  if (pathname === '/' && isAuthenticated) {
    return NextResponse.redirect(new URL('/dashboard', request.url));
  }
  
  // If root path and not authenticated, redirect to login
  if (pathname === '/' && !isAuthenticated) {
    return NextResponse.redirect(new URL('/login', request.url));
  }
  
  return NextResponse.next();
}

// Configure which routes use this middleware
export const config = {
  matcher: [
    '/',
    '/login',
    '/dashboard/:path*',
    '/users/:path*',
    '/motorcycles/:path*',
    '/clients/:path*',
    '/rentals/:path*',
    '/reports/:path*',
  ],
};
