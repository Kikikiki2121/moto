'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

type UserFormProps = {
  editMode?: boolean;
  userId?: number;
};

type UserFormData = {
  username: string;
  password: string;
  confirm_password: string;
  full_name: string;
  email: string;
  role: string;
  permissions: string;
};

export default function UserForm({ editMode = false, userId }: UserFormProps) {
  const [formData, setFormData] = useState<UserFormData>({
    username: '',
    password: '',
    confirm_password: '',
    full_name: '',
    email: '',
    role: 'staff',
    permissions: ''
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const router = useRouter();

  // Fetch user data if in edit mode
  useState(() => {
    if (editMode && userId) {
      const fetchUser = async () => {
        try {
          const response = await fetch(`/api/auth/users/${userId}`);
          const data = await response.json();
          
          if (data.success) {
            setFormData({
              ...formData,
              username: data.user.username,
              full_name: data.user.full_name,
              email: data.user.email,
              role: data.user.role,
              permissions: data.user.permissions || ''
            });
          } else {
            setError(data.message || 'Не удалось загрузить данные пользователя');
          }
        } catch (err) {
          setError('Ошибка при загрузке данных пользователя');
          console.error('Fetch error:', err);
        }
      };
      
      fetchUser();
    }
  }, [editMode, userId]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setLoading(true);

    // Validate form
    if (formData.password !== formData.confirm_password) {
      setError('Пароли не совпадают');
      setLoading(false);
      return;
    }

    try {
      let response;
      
      if (editMode && userId) {
        // Update existing user
        const updateData = { ...formData };
        // Only include password if it was provided
        if (!updateData.password) {
          delete updateData.password;
        }
        delete updateData.confirm_password;
        
        response = await fetch(`/api/auth/users/${userId}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(updateData),
        });
      } else {
        // Create new user
        response = await fetch('/api/auth/users', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(formData),
        });
      }

      const data = await response.json();

      if (data.success) {
        setSuccess(data.message || 'Операция выполнена успешно');
        
        if (!editMode) {
          // Clear form after successful creation
          setFormData({
            username: '',
            password: '',
            confirm_password: '',
            full_name: '',
            email: '',
            role: 'staff',
            permissions: ''
          });
        }
        
        // Redirect after a short delay
        setTimeout(() => {
          router.push('/users');
        }, 2000);
      } else {
        setError(data.message || 'Произошла ошибка');
      }
    } catch (err) {
      setError('Произошла ошибка при отправке данных');
      console.error('Submit error:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">
        {editMode ? 'Редактирование пользователя' : 'Создание нового пользователя'}
      </h1>
      
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}
      
      {success && (
        <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
          {success}
        </div>
      )}
      
      <form onSubmit={handleSubmit} className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="username">
            Имя пользователя
          </label>
          <input
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            id="username"
            type="text"
            name="username"
            value={formData.username}
            onChange={handleChange}
            required
            disabled={editMode} // Username cannot be changed in edit mode
          />
        </div>
        
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="password">
            Пароль {editMode && '(оставьте пустым, чтобы не менять)'}
          </label>
          <input
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            id="password"
            type="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            required={!editMode}
          />
        </div>
        
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="confirm_password">
            Подтверждение пароля
          </label>
          <input
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            id="confirm_password"
            type="password"
            name="confirm_password"
            value={formData.confirm_password}
            onChange={handleChange}
            required={!editMode || formData.password !== ''}
          />
        </div>
        
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="full_name">
            Полное имя
          </label>
          <input
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            id="full_name"
            type="text"
            name="full_name"
            value={formData.full_name}
            onChange={handleChange}
            required
          />
        </div>
        
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="email">
            Email
          </label>
          <input
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            id="email"
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            required
          />
        </div>
        
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="role">
            Роль
          </label>
          <select
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            id="role"
            name="role"
            value={formData.role}
            onChange={handleChange}
            required
          >
            <option value="super_admin">Суперадминистратор</option>
            <option value="admin">Администратор</option>
            <option value="staff">Сотрудник</option>
          </select>
        </div>
        
        <div className="mb-6">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="permissions">
            Права доступа (через запятую)
          </label>
          <textarea
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            id="permissions"
            name="permissions"
            value={formData.permissions}
            onChange={handleChange}
            rows={3}
            placeholder="manage_users,view_reports,edit_motorcycles"
          />
          <p className="text-sm text-gray-600 mt-1">
            Оставьте пустым для стандартных прав или введите "all" для полного доступа
          </p>
        </div>
        
        <div className="flex items-center justify-between">
          <button
            className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
            type="submit"
            disabled={loading}
          >
            {loading ? 'Обработка...' : (editMode ? 'Сохранить изменения' : 'Создать пользователя')}
          </button>
          <button
            className="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
            type="button"
            onClick={() => router.push('/users')}
          >
            Отмена
          </button>
        </div>
      </form>
    </div>
  );
}
