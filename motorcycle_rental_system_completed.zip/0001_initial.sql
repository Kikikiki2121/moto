-- Migration number: 0001 	 2025-04-07
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS motorcycles;
DROP TABLE IF EXISTS clients;
DROP TABLE IF EXISTS rentals;
DROP TABLE IF EXISTS documents;
DROP TABLE IF EXISTS notifications;

-- Users table for authentication and access control
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  full_name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('super_admin', 'admin', 'staff')),
  permissions TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_login DATETIME
);

-- Motorcycles table
CREATE TABLE IF NOT EXISTS motorcycles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  brand TEXT NOT NULL,
  model TEXT NOT NULL,
  license_plate TEXT UNIQUE NOT NULL,
  year INTEGER,
  color TEXT,
  daily_rate REAL NOT NULL,
  weekly_rate REAL NOT NULL,
  monthly_rate REAL NOT NULL,
  deposit_amount REAL NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('available', 'rented', 'maintenance', 'reserved')),
  notes TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Clients table
CREATE TABLE IF NOT EXISTS clients (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  full_name TEXT NOT NULL,
  email TEXT,
  phone TEXT NOT NULL,
  address TEXT,
  passport_number TEXT NOT NULL,
  passport_issue_date DATE,
  passport_expiry_date DATE,
  driver_license_number TEXT,
  driver_license_expiry DATE,
  notes TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Rentals table
CREATE TABLE IF NOT EXISTS rentals (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  motorcycle_id INTEGER NOT NULL,
  client_id INTEGER NOT NULL,
  start_date DATETIME NOT NULL,
  end_date DATETIME NOT NULL,
  actual_return_date DATETIME,
  rental_type TEXT NOT NULL CHECK (rental_type IN ('daily', 'weekly', 'monthly')),
  rental_rate REAL NOT NULL,
  total_amount REAL NOT NULL,
  deposit_amount REAL NOT NULL,
  deposit_returned BOOLEAN DEFAULT FALSE,
  deposit_returned_date DATETIME,
  deposit_deduction_amount REAL DEFAULT 0,
  deposit_deduction_reason TEXT,
  status TEXT NOT NULL CHECK (status IN ('active', 'completed', 'overdue', 'cancelled')),
  contract_number TEXT UNIQUE NOT NULL,
  created_by INTEGER NOT NULL,
  notes TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (motorcycle_id) REFERENCES motorcycles (id),
  FOREIGN KEY (client_id) REFERENCES clients (id),
  FOREIGN KEY (created_by) REFERENCES users (id)
);

-- Documents table for storing file references
CREATE TABLE IF NOT EXISTS documents (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  related_to TEXT NOT NULL CHECK (related_to IN ('client', 'rental')),
  related_id INTEGER NOT NULL,
  document_type TEXT NOT NULL CHECK (document_type IN ('passport', 'driver_license', 'contract', 'invoice', 'other')),
  file_path TEXT NOT NULL,
  file_name TEXT NOT NULL,
  uploaded_by INTEGER NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (uploaded_by) REFERENCES users (id)
);

-- Notifications table
CREATE TABLE IF NOT EXISTS notifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  related_to TEXT CHECK (related_to IN ('rental', 'client', 'motorcycle', 'system')),
  related_id INTEGER,
  is_read BOOLEAN DEFAULT FALSE,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users (id)
);

-- Create initial super admin user (password: admin123)
INSERT INTO users (username, password_hash, full_name, email, role, permissions) VALUES 
  ('admin', '$2a$10$JNVXBBk.CgfRwxAVo5QAz.Vd5AyIW0XjcRwKY9XRgBmkwXjcMjKZe', 'System Administrator', 'admin@example.com', 'super_admin', 'all');

-- Create indexes
CREATE INDEX idx_motorcycles_status ON motorcycles(status);
CREATE INDEX idx_clients_phone ON clients(phone);
CREATE INDEX idx_clients_passport ON clients(passport_number);
CREATE INDEX idx_rentals_status ON rentals(status);
CREATE INDEX idx_rentals_dates ON rentals(start_date, end_date);
CREATE INDEX idx_rentals_motorcycle ON rentals(motorcycle_id);
CREATE INDEX idx_rentals_client ON rentals(client_id);
CREATE INDEX idx_documents_related ON documents(related_to, related_id);
CREATE INDEX idx_notifications_user ON notifications(user_id, is_read);
