'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';

type Client = {
  id: number;
  full_name: string;
  email: string | null;
  phone: string;
  address: string | null;
  passport_number: string;
  passport_issue_date: string | null;
  passport_expiry_date: string | null;
  driver_license_number: string | null;
  driver_license_expiry: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
};

type ClientListProps = {
  initialClients?: Client[];
};

export default function ClientList({ initialClients }: ClientListProps) {
  const [clients, setClients] = useState<Client[]>(initialClients || []);
  const [loading, setLoading] = useState(!initialClients);
  const [error, setError] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const router = useRouter();

  useEffect(() => {
    if (!initialClients) {
      fetchClients();
    }
  }, [initialClients]);

  const fetchClients = async (filters = {}) => {
    setLoading(true);
    setError('');

    try {
      let url = '/api/clients';
      const params = new URLSearchParams();
      
      if (searchTerm) {
        params.append('search', searchTerm);
      }
      
      // Add any additional filters
      Object.entries(filters).forEach(([key, value]) => {
        if (value) {
          params.append(key, value as string);
        }
      });
      
      if (params.toString()) {
        url += `?${params.toString()}`;
      }

      const response = await fetch(url);
      const data = await response.json();

      if (data.success) {
        setClients(data.clients || []);
      } else {
        setError(data.message || 'Не удалось загрузить список клиентов');
      }
    } catch (err) {
      setError('Ошибка при загрузке данных');
      console.error('Fetch clients error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    fetchClients();
  };

  const handleDeleteClient = async (id: number) => {
    if (!confirm('Вы уверены, что хотите удалить этого клиента?')) {
      return;
    }

    try {
      const response = await fetch(`/api/clients/${id}`, {
        method: 'DELETE',
      });

      const data = await response.json();

      if (data.success) {
        // Remove client from list
        setClients(clients.filter(client => client.id !== id));
      } else {
        setError(data.message || 'Не удалось удалить клиента');
      }
    } catch (err) {
      setError('Ошибка при удалении клиента');
      console.error('Delete client error:', err);
    }
  };

  if (loading && !clients.length) {
    return <div className="text-center p-8">Загрузка...</div>;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">Управление клиентами</h1>

      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}

      <div className="flex flex-col md:flex-row justify-between mb-6 gap-4">
        <form onSubmit={handleSearch} className="flex gap-2">
          <input
            type="text"
            placeholder="Поиск по имени, телефону или паспорту"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="border rounded px-3 py-2 w-full md:w-64"
          />
          <button
            type="submit"
            className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded"
          >
            Поиск
          </button>
        </form>

        <button
          onClick={() => router.push('/clients/new')}
          className="bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 rounded"
        >
          Добавить клиента
        </button>
      </div>

      {clients.length === 0 ? (
        <div className="text-center p-8 bg-gray-50 rounded">
          Клиенты не найдены
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="min-w-full bg-white border border-gray-200">
            <thead>
              <tr>
                <th className="py-2 px-4 border-b">ID</th>
                <th className="py-2 px-4 border-b">ФИО</th>
                <th className="py-2 px-4 border-b">Телефон</th>
                <th className="py-2 px-4 border-b">Email</th>
                <th className="py-2 px-4 border-b">Номер паспорта</th>
                <th className="py-2 px-4 border-b">Действия</th>
              </tr>
            </thead>
            <tbody>
              {clients.map(client => (
                <tr key={client.id} className="hover:bg-gray-50">
                  <td className="py-2 px-4 border-b">{client.id}</td>
                  <td className="py-2 px-4 border-b">{client.full_name}</td>
                  <td className="py-2 px-4 border-b">{client.phone}</td>
                  <td className="py-2 px-4 border-b">{client.email || '-'}</td>
                  <td className="py-2 px-4 border-b">{client.passport_number}</td>
                  <td className="py-2 px-4 border-b">
                    <div className="flex space-x-2">
                      <button
                        onClick={() => router.push(`/clients/${client.id}`)}
                        className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-1 px-2 rounded text-sm"
                      >
                        Просмотр
                      </button>
                      <button
                        onClick={() => router.push(`/clients/edit/${client.id}`)}
                        className="bg-yellow-500 hover:bg-yellow-600 text-white font-bold py-1 px-2 rounded text-sm"
                      >
                        Изменить
                      </button>
                      <button
                        onClick={() => handleDeleteClient(client.id)}
                        className="bg-red-500 hover:bg-red-600 text-white font-bold py-1 px-2 rounded text-sm"
                      >
                        Удалить
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
