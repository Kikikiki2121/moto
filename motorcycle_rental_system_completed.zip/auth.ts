import { cookies } from 'next/headers';
import { jwtVerify, SignJWT } from 'jose';
import bcrypt from 'bcryptjs';
import { D1Database } from '@cloudflare/workers-types';

// Types
export type UserRole = 'super_admin' | 'admin' | 'staff';

export interface User {
  id: number;
  username: string;
  full_name: string;
  email: string;
  role: UserRole;
  permissions: string | null;
}

export interface AuthResult {
  success: boolean;
  message: string;
  user?: User;
  token?: string;
}

// JWT configuration
const JWT_SECRET = new TextEncoder().encode(
  process.env.JWT_SECRET || 'motorcycle-rental-system-secret-key-change-in-production'
);
const JWT_EXPIRY = '8h';

// Helper functions
export async function hashPassword(password: string): Promise<string> {
  return await bcrypt.hash(password, 10);
}

export async function comparePasswords(password: string, hashedPassword: string): Promise<boolean> {
  return await bcrypt.compare(password, hashedPassword);
}

export async function createToken(user: User): Promise<string> {
  const token = await new SignJWT({ 
    id: user.id, 
    username: user.username,
    role: user.role,
    permissions: user.permissions
  })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime(JWT_EXPIRY)
    .sign(JWT_SECRET);
  
  return token;
}

export async function verifyToken(token: string): Promise<any> {
  try {
    const { payload } = await jwtVerify(token, JWT_SECRET);
    return payload;
  } catch (error) {
    return null;
  }
}

// Authentication functions
export async function login(
  db: D1Database,
  username: string, 
  password: string
): Promise<AuthResult> {
  try {
    const userResult = await db.prepare(
      'SELECT id, username, password_hash, full_name, email, role, permissions FROM users WHERE username = ?'
    ).bind(username).first();
    
    if (!userResult) {
      return { success: false, message: 'Неверное имя пользователя или пароль' };
    }
    
    const isPasswordValid = await comparePasswords(password, userResult.password_hash as string);
    
    if (!isPasswordValid) {
      return { success: false, message: 'Неверное имя пользователя или пароль' };
    }
    
    // Update last login time
    await db.prepare(
      'UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?'
    ).bind(userResult.id).run();
    
    const user: User = {
      id: userResult.id as number,
      username: userResult.username as string,
      full_name: userResult.full_name as string,
      email: userResult.email as string,
      role: userResult.role as UserRole,
      permissions: userResult.permissions as string | null
    };
    
    const token = await createToken(user);
    
    return {
      success: true,
      message: 'Вход выполнен успешно',
      user,
      token
    };
  } catch (error) {
    console.error('Login error:', error);
    return { success: false, message: 'Ошибка при входе в систему' };
  }
}

export async function getCurrentUser(db: D1Database, request: Request): Promise<User | null> {
  const cookieStore = cookies();
  const token = cookieStore.get('auth_token')?.value;
  
  if (!token) {
    return null;
  }
  
  try {
    const payload = await verifyToken(token);
    
    if (!payload || !payload.id) {
      return null;
    }
    
    const userResult = await db.prepare(
      'SELECT id, username, full_name, email, role, permissions FROM users WHERE id = ?'
    ).bind(payload.id).first();
    
    if (!userResult) {
      return null;
    }
    
    return {
      id: userResult.id as number,
      username: userResult.username as string,
      full_name: userResult.full_name as string,
      email: userResult.email as string,
      role: userResult.role as UserRole,
      permissions: userResult.permissions as string | null
    };
  } catch (error) {
    console.error('Get current user error:', error);
    return null;
  }
}

// Permission checking
export function hasPermission(user: User | null, requiredPermission: string): boolean {
  if (!user) return false;
  
  // Super admin has all permissions
  if (user.role === 'super_admin') return true;
  
  // Check specific permissions
  if (user.permissions) {
    if (user.permissions === 'all') return true;
    
    const permissions = user.permissions.split(',').map(p => p.trim());
    return permissions.includes(requiredPermission);
  }
  
  return false;
}

// Role-based access control
export function hasRole(user: User | null, requiredRoles: UserRole[]): boolean {
  if (!user) return false;
  return requiredRoles.includes(user.role);
}

// User management functions
export async function createUser(
  db: D1Database,
  userData: {
    username: string;
    password: string;
    full_name: string;
    email: string;
    role: UserRole;
    permissions?: string;
  },
  currentUser: User
): Promise<AuthResult> {
  // Check if current user has permission to create users
  if (!hasPermission(currentUser, 'manage_users')) {
    return { success: false, message: 'Недостаточно прав для создания пользователей' };
  }
  
  // Super admin can create any user, admin can only create staff
  if (currentUser.role === 'admin' && userData.role !== 'staff') {
    return { success: false, message: 'Администратор может создавать только сотрудников' };
  }
  
  try {
    // Check if username or email already exists
    const existingUser = await db.prepare(
      'SELECT id FROM users WHERE username = ? OR email = ?'
    ).bind(userData.username, userData.email).first();
    
    if (existingUser) {
      return { success: false, message: 'Пользователь с таким именем или email уже существует' };
    }
    
    const hashedPassword = await hashPassword(userData.password);
    
    await db.prepare(`
      INSERT INTO users (username, password_hash, full_name, email, role, permissions)
      VALUES (?, ?, ?, ?, ?, ?)
    `).bind(
      userData.username,
      hashedPassword,
      userData.full_name,
      userData.email,
      userData.role,
      userData.permissions || null
    ).run();
    
    return { success: true, message: 'Пользователь успешно создан' };
  } catch (error) {
    console.error('Create user error:', error);
    return { success: false, message: 'Ошибка при создании пользователя' };
  }
}

export async function updateUser(
  db: D1Database,
  userId: number,
  userData: {
    full_name?: string;
    email?: string;
    role?: UserRole;
    permissions?: string;
    password?: string;
  },
  currentUser: User
): Promise<AuthResult> {
  // Check if current user has permission to update users
  if (!hasPermission(currentUser, 'manage_users')) {
    return { success: false, message: 'Недостаточно прав для обновления пользователей' };
  }
  
  // Get user to update
  const userToUpdate = await db.prepare(
    'SELECT role FROM users WHERE id = ?'
  ).bind(userId).first();
  
  if (!userToUpdate) {
    return { success: false, message: 'Пользователь не найден' };
  }
  
  // Permission checks based on roles
  if (currentUser.role === 'admin') {
    // Admin can only update staff users
    if (userToUpdate.role !== 'staff') {
      return { success: false, message: 'Администратор может обновлять только сотрудников' };
    }
    
    // Admin cannot change role to anything other than staff
    if (userData.role && userData.role !== 'staff') {
      return { success: false, message: 'Администратор не может изменить роль на другую, кроме сотрудника' };
    }
  }
  
  try {
    let query = 'UPDATE users SET ';
    const params: any[] = [];
    const setClauses: string[] = [];
    
    if (userData.full_name) {
      setClauses.push('full_name = ?');
      params.push(userData.full_name);
    }
    
    if (userData.email) {
      setClauses.push('email = ?');
      params.push(userData.email);
    }
    
    if (userData.role) {
      setClauses.push('role = ?');
      params.push(userData.role);
    }
    
    if (userData.permissions !== undefined) {
      setClauses.push('permissions = ?');
      params.push(userData.permissions || null);
    }
    
    if (userData.password) {
      setClauses.push('password_hash = ?');
      params.push(await hashPassword(userData.password));
    }
    
    setClauses.push('updated_at = CURRENT_TIMESTAMP');
    
    if (setClauses.length === 0) {
      return { success: false, message: 'Нет данных для обновления' };
    }
    
    query += setClauses.join(', ') + ' WHERE id = ?';
    params.push(userId);
    
    await db.prepare(query).bind(...params).run();
    
    return { success: true, message: 'Пользователь успешно обновлен' };
  } catch (error) {
    console.error('Update user error:', error);
    return { success: false, message: 'Ошибка при обновлении пользователя' };
  }
}

export async function deleteUser(
  db: D1Database,
  userId: number,
  currentUser: User
): Promise<AuthResult> {
  // Check if current user has permission to delete users
  if (!hasPermission(currentUser, 'manage_users')) {
    return { success: false, message: 'Недостаточно прав для удаления пользователей' };
  }
  
  // Get user to delete
  const userToDelete = await db.prepare(
    'SELECT role FROM users WHERE id = ?'
  ).bind(userId).first();
  
  if (!userToDelete) {
    return { success: false, message: 'Пользователь не найден' };
  }
  
  // Permission checks based on roles
  if (currentUser.role === 'admin' && userToDelete.role !== 'staff') {
    return { success: false, message: 'Администратор может удалять только сотрудников' };
  }
  
  // Prevent deleting the last super_admin
  if (userToDelete.role === 'super_admin') {
    const superAdminCount = await db.prepare(
      'SELECT COUNT(*) as count FROM users WHERE role = "super_admin"'
    ).first();
    
    if (superAdminCount && superAdminCount.count <= 1) {
      return { success: false, message: 'Невозможно удалить последнего суперадминистратора' };
    }
  }
  
  try {
    await db.prepare('DELETE FROM users WHERE id = ?').bind(userId).run();
    return { success: true, message: 'Пользователь успешно удален' };
  } catch (error) {
    console.error('Delete user error:', error);
    return { success: false, message: 'Ошибка при удалении пользователя' };
  }
}
