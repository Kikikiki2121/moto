import { D1Database } from '@cloudflare/workers-types';
import { Motorcycle } from './motorcycle';
import { Client } from './client';

export interface Rental {
  id: number;
  motorcycle_id: number;
  client_id: number;
  start_date: string;
  end_date: string;
  actual_return_date: string | null;
  rental_type: 'daily' | 'weekly' | 'monthly';
  rental_rate: number;
  total_amount: number;
  deposit_amount: number;
  deposit_returned: boolean;
  deposit_returned_date: string | null;
  deposit_deduction_amount: number;
  deposit_deduction_reason: string | null;
  status: 'active' | 'completed' | 'overdue' | 'cancelled';
  contract_number: string;
  created_by: number;
  notes: string | null;
  created_at: string;
  updated_at: string;
  
  // Joined data
  motorcycle?: Motorcycle;
  client?: Client;
}

export interface RentalCreateInput {
  motorcycle_id: number;
  client_id: number;
  start_date: string;
  end_date: string;
  rental_type: 'daily' | 'weekly' | 'monthly';
  rental_rate: number;
  total_amount: number;
  deposit_amount: number;
  contract_number: string;
  created_by: number;
  notes?: string;
}

export interface RentalUpdateInput {
  motorcycle_id?: number;
  client_id?: number;
  start_date?: string;
  end_date?: string;
  actual_return_date?: string | null;
  rental_type?: 'daily' | 'weekly' | 'monthly';
  rental_rate?: number;
  total_amount?: number;
  deposit_amount?: number;
  deposit_returned?: boolean;
  deposit_returned_date?: string | null;
  deposit_deduction_amount?: number;
  deposit_deduction_reason?: string | null;
  status?: 'active' | 'completed' | 'overdue' | 'cancelled';
  contract_number?: string;
  notes?: string;
}

export interface RentalQueryOptions {
  status?: 'active' | 'completed' | 'overdue' | 'cancelled';
  client_id?: number;
  motorcycle_id?: number;
  start_date_from?: string;
  start_date_to?: string;
  end_date_from?: string;
  end_date_to?: string;
  search?: string;
  limit?: number;
  offset?: number;
  include_motorcycle?: boolean;
  include_client?: boolean;
}

export interface RentalResult {
  success: boolean;
  message: string;
  rental?: Rental;
  rentals?: Rental[];
  total?: number;
}

export async function getRentals(
  db: D1Database,
  options: RentalQueryOptions = {}
): Promise<RentalResult> {
  try {
    let query = `
      SELECT r.id, r.motorcycle_id, r.client_id, r.start_date, r.end_date, 
             r.actual_return_date, r.rental_type, r.rental_rate, r.total_amount, 
             r.deposit_amount, r.deposit_returned, r.deposit_returned_date, 
             r.deposit_deduction_amount, r.deposit_deduction_reason, r.status, 
             r.contract_number, r.created_by, r.notes, r.created_at, r.updated_at
      FROM rentals r
      WHERE 1=1
    `;
    
    const params: any[] = [];
    
    if (options.status) {
      query += ` AND r.status = ?`;
      params.push(options.status);
    }
    
    if (options.client_id) {
      query += ` AND r.client_id = ?`;
      params.push(options.client_id);
    }
    
    if (options.motorcycle_id) {
      query += ` AND r.motorcycle_id = ?`;
      params.push(options.motorcycle_id);
    }
    
    if (options.start_date_from) {
      query += ` AND r.start_date >= ?`;
      params.push(options.start_date_from);
    }
    
    if (options.start_date_to) {
      query += ` AND r.start_date <= ?`;
      params.push(options.start_date_to);
    }
    
    if (options.end_date_from) {
      query += ` AND r.end_date >= ?`;
      params.push(options.end_date_from);
    }
    
    if (options.end_date_to) {
      query += ` AND r.end_date <= ?`;
      params.push(options.end_date_to);
    }
    
    if (options.search) {
      query += ` AND (r.contract_number LIKE ? OR r.notes LIKE ?)`;
      const searchTerm = `%${options.search}%`;
      params.push(searchTerm, searchTerm);
    }
    
    // Get total count
    const countQuery = query.replace(
      'SELECT r.id, r.motorcycle_id, r.client_id, r.start_date, r.end_date, \n             r.actual_return_date, r.rental_type, r.rental_rate, r.total_amount, \n             r.deposit_amount, r.deposit_returned, r.deposit_returned_date, \n             r.deposit_deduction_amount, r.deposit_deduction_reason, r.status, \n             r.contract_number, r.created_by, r.notes, r.created_at, r.updated_at',
      'SELECT COUNT(*) as total'
    );
    
    const countResult = await db.prepare(countQuery).bind(...params).first();
    const total = countResult ? (countResult.total as number) : 0;
    
    // Add sorting and pagination
    query += ` ORDER BY r.start_date DESC, r.id DESC`;
    
    if (options.limit) {
      query += ` LIMIT ?`;
      params.push(options.limit);
      
      if (options.offset) {
        query += ` OFFSET ?`;
        params.push(options.offset);
      }
    }
    
    const result = await db.prepare(query).bind(...params).all();
    let rentals = result.results as Rental[];
    
    // Include related data if requested
    if ((options.include_motorcycle || options.include_client) && rentals.length > 0) {
      // Get all motorcycle IDs and client IDs
      const motorcycleIds = options.include_motorcycle ? 
        [...new Set(rentals.map(r => r.motorcycle_id))] : [];
      
      const clientIds = options.include_client ? 
        [...new Set(rentals.map(r => r.client_id))] : [];
      
      // Fetch motorcycles if needed
      let motorcycles: Record<number, Motorcycle> = {};
      if (motorcycleIds.length > 0) {
        const motorcycleQuery = `
          SELECT id, brand, model, license_plate, year, color, 
                 daily_rate, weekly_rate, monthly_rate, deposit_amount, 
                 status, notes, created_at, updated_at
          FROM motorcycles
          WHERE id IN (${motorcycleIds.map(() => '?').join(',')})
        `;
        
        const motorcycleResult = await db.prepare(motorcycleQuery).bind(...motorcycleIds).all();
        motorcycles = (motorcycleResult.results as Motorcycle[]).reduce((acc, m) => {
          acc[m.id] = m;
          return acc;
        }, {} as Record<number, Motorcycle>);
      }
      
      // Fetch clients if needed
      let clients: Record<number, Client> = {};
      if (clientIds.length > 0) {
        const clientQuery = `
          SELECT id, full_name, email, phone, address, 
                 passport_number, passport_issue_date, passport_expiry_date,
                 driver_license_number, driver_license_expiry,
                 notes, created_at, updated_at
          FROM clients
          WHERE id IN (${clientIds.map(() => '?').join(',')})
        `;
        
        const clientResult = await db.prepare(clientQuery).bind(...clientIds).all();
        clients = (clientResult.results as Client[]).reduce((acc, c) => {
          acc[c.id] = c;
          return acc;
        }, {} as Record<number, Client>);
      }
      
      // Add related data to rentals
      rentals = rentals.map(rental => ({
        ...rental,
        motorcycle: options.include_motorcycle ? motorcycles[rental.motorcycle_id] : undefined,
        client: options.include_client ? clients[rental.client_id] : undefined
      }));
    }
    
    return {
      success: true,
      message: 'Аренды успешно получены',
      rentals,
      total
    };
  } catch (error) {
    console.error('Get rentals error:', error);
    return {
      success: false,
      message: 'Ошибка при получении списка аренд'
    };
  }
}

export async function getRentalById(
  db: D1Database,
  id: number,
  options: {
    include_motorcycle?: boolean;
    include_client?: boolean;
  } = {}
): Promise<RentalResult> {
  try {
    const result = await db.prepare(`
      SELECT id, motorcycle_id, client_id, start_date, end_date, 
             actual_return_date, rental_type, rental_rate, total_amount, 
             deposit_amount, deposit_returned, deposit_returned_date, 
             deposit_deduction_amount, deposit_deduction_reason, status, 
             contract_number, created_by, notes, created_at, updated_at
      FROM rentals
      WHERE id = ?
    `).bind(id).first();
    
    if (!result) {
      return {
        success: false,
        message: 'Аренда не найдена'
      };
    }
    
    let rental = result as Rental;
    
    // Include related data if requested
    if (options.include_motorcycle || options.include_client) {
      // Fetch motorcycle if needed
      if (options.include_motorcycle) {
        const motorcycleResult = await db.prepare(`
          SELECT id, brand, model, license_plate, year, color, 
                 daily_rate, weekly_rate, monthly_rate, deposit_amount, 
                 status, notes, created_at, updated_at
          FROM motorcycles
          WHERE id = ?
        `).bind(rental.motorcycle_id).first();
        
        if (motorcycleResult) {
          rental.motorcycle = motorcycleResult as Motorcycle;
        }
      }
      
      // Fetch client if needed
      if (options.include_client) {
        const clientResult = await db.prepare(`
          SELECT id, full_name, email, phone, address, 
                 passport_number, passport_issue_date, passport_expiry_date,
                 driver_license_number, driver_license_expiry,
                 notes, created_at, updated_at
          FROM clients
          WHERE id = ?
        `).bind(rental.client_id).first();
        
        if (clientResult) {
          rental.client = clientResult as Client;
        }
      }
    }
    
    return {
      success: true,
      message: 'Аренда успешно получена',
      rental
    };
  } catch (error) {
    console.error('Get rental by ID error:', error);
    return {
      success: false,
      message: 'Ошибка при получении данных аренды'
    };
  }
}

export async function createRental(
  db: D1Database,
  data: RentalCreateInput
): Promise<RentalResult> {
  try {
    // Check if motorcycle exists and is available
    const motorcycleResult = await db.prepare(
      'SELECT id, status FROM motorcycles WHERE id = ?'
    ).bind(data.motorcycle_id).first();
    
    if (!motorcycleResult) {
      return {
        success: false,
        message: 'Мотоцикл не найден'
      };
    }
    
    if (motorcycleResult.status !== 'available') {
      return {
        success: false,
        message: 'Мотоцикл недоступен для аренды'
      };
    }
    
    // Check if client exists
    const clientResult = await db.prepare(
      'SELECT id FROM clients WHERE id = ?'
    ).bind(data.client_id).first();
    
    if (!clientResult) {
      return {
        success: false,
        message: 'Клиент не найден'
      };
    }
    
    // Check if contract number is unique
    const existingContract = await db.prepare(
      'SELECT id FROM rentals WHERE contract_number = ?'
    ).bind(data.contract_number).first();
    
    if (existingContract) {
      return {
        success: false,
        message: 'Договор с таким номером уже существует'
      };
    }
    
    // Start a transaction
    // Note: D1 doesn't support transactions in the same way as traditional SQL databases
    // We'll need to handle this with multiple operations
    
    // 1. Create the rental
    const rentalResult = await db.prepare(`
      INSERT INTO rentals (
        motorcycle_id, client_id, start_date, end_date,
        rental_type, rental_rate, total_amount, deposit_amount,
        deposit_returned, deposit_deduction_amount, status,
        contract_number, created_by, notes
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      data.motorcycle_id,
      data.client_id,
      data.start_date,
      data.end_date,
      data.rental_type,
      data.rental_rate,
      data.total_amount,
      data.deposit_amount,
      false, // deposit_returned
      0, // deposit_deduction_amount
      'active', // status
      data.contract_number,
      data.created_by,
      data.notes || null
    ).run();
    
    if (!rentalResult.success) {
      return {
        success: false,
        message: 'Ошибка при создании аренды'
      };
    }
    
    // 2. Update motorcycle status to 'rented'
    const motorcycleUpdateResult = await db.prepare(`
      UPDATE motorcycles
      SET status = 'rented', updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).bind(data.motorcycle_id).run();
    
    if (!motorcycleUpdateResult.success) {
      // Ideally, we would rollback the rental creation here
      console.error('Failed to update motorcycle status');
    }
    
    // Get the created rental with related data
    const createdRental = await db.prepare(
      'SELECT * FROM rentals WHERE contract_number = ?'
    ).bind(data.contract_number).first();
    
    return {
      success: true,
      message: 'Аренда успешно создана',
      rental: createdRental as Rental
    };
  } catch (error) {
    console.error('Create rental error:', error);
    return {
      success: false,
      message: 'Ошибка при создании аренды'
    };
  }
}

export async function updateRental(
  db: D1Database,
  id: number,
  data: RentalUpdateInput
): Promise<RentalResult> {
  try {
    // Check if rental exists
    const existingRental = await db.prepare(
      'SELECT id, motorcycle_id, status FROM rentals WHERE id = ?'
    ).bind(id).first();
    
    if (!existingRental) {
      return {
        success: false,
        message: 'Аренда не найдена'
      };
    }
    
    // Check if contract number is unique if it's being updated
    if (data.contract_number) {
      const duplicateContract = await db.prepare(
        'SELECT id FROM rentals WHERE contract_number = ? AND id != ?'
      ).bind(data.contract_number, id).first();
      
      if (duplicateContract) {
        return {
          success: false,
          message: 'Договор с таким номером уже существует'
        };
      }
    }
    
    // If motorcycle is being changed, check if new motorcycle exists and is available
    if (data.motorcycle_id && data.motorcycle_id !== existingRental.motorcycle_id) {
      const newMotorcycleResult = await db.prepare(
        'SELECT id, status FROM motorcycles WHERE id = ?'
      ).bind(data.motorcycle_id).first();
      
      if (!newMotorcycleResult) {
        return {
          success: false,
          message: 'Новый мотоцикл не найден'
        };
      }
      
      if (newMotorcycleResult.status !== 'available') {
        return {
          success: false,
          message: 'Новый мотоцикл недоступен для аренды'
        };
      }
    }
    
    // If client is being changed, check if new client exists
    if (data.client_id) {
      const clientResult = await db.prepare(
        'SELECT id FROM clients WHERE id = ?'
      ).bind(data.client_id).first();
      
      if (!clientResult) {
        return {
          success: false,
          message: 'Клиент не найден'
        };
      }
    }
    
    // Build update query
    let query = 'UPDATE rentals SET ';
    const setClauses: string[] = [];
    const params: any[] = [];
    
    if (data.motorcycle_id !== undefined) {
      setClauses.push('motorcycle_id = ?');
      params.push(data.motorcycle_id);
    }
    
    if (data.client_id !== undefined) {
      setClauses.push('client_id = ?');
      params.push(data.client_id);
    }
    
    if (data.start_date !== undefined) {
      setClauses.push('start_date = ?');
      params.push(data.start_date);
    }
    
    if (data.end_date !== undefined) {
      setClauses.push('end_date = ?');
      params.push(data.end_date);
    }
    
    if (data.actual_return_date !== undefined) {
      setClauses.push('actual_return_date = ?');
      params.push(data.actual_return_date);
    }
    
    if (data.rental_type !== undefined) {
      setClauses.push('rental_type = ?');
      params.push(data.rental_type);
    }
    
    if (data.rental_rate !== undefined) {
      setClauses.push('rental_rate = ?');
      params.push(data.rental_rate);
    }
    
    if (data.total_amount !== undefined) {
      setClauses.push('total_amount = ?');
  
(Content truncated due to size limit. Use line ranges to read in chunks)