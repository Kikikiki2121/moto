'use client';

import { useState } from 'react';
import { FiMail, FiCheck, FiAlertTriangle } from 'react-icons/fi';

interface EmailSenderProps {
  rentalId: number;
  clientEmail: string;
  clientName: string;
  documentUrl?: string;
  documentType?: 'contract' | 'invoice';
}

export default function EmailSender({
  rentalId,
  clientEmail,
  clientName,
  documentUrl,
  documentType
}: EmailSenderProps) {
  const [sending, setSending] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [emailSubject, setEmailSubject] = useState(
    documentType === 'contract' 
      ? 'Договор аренды мотоцикла' 
      : documentType === 'invoice' 
        ? 'Счет на оплату аренды мотоцикла' 
        : 'Информация об аренде мотоцикла'
  );
  const [emailBody, setEmailBody] = useState(
    `Уважаемый(ая) ${clientName},\n\n` +
    (documentType === 'contract' 
      ? 'Во вложении находится договор аренды мотоцикла. Пожалуйста, ознакомьтесь с условиями и сохраните документ.\n\n' 
      : documentType === 'invoice' 
        ? 'Во вложении находится счет на оплату аренды мотоцикла. Пожалуйста, произведите оплату в ближайшее время.\n\n'
        : 'Информация о вашей аренде мотоцикла.\n\n') +
    'С уважением,\nКоманда МотоРент'
  );

  const handleSendEmail = async () => {
    if (!clientEmail) {
      setError('Email клиента не указан');
      return;
    }

    setSending(true);
    setError('');
    setSuccess('');

    try {
      const response = await fetch(`/api/email/send`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          rentalId,
          to: clientEmail,
          subject: emailSubject,
          body: emailBody,
          documentUrl,
          documentType
        }),
      });

      const data = await response.json();

      if (data.success) {
        setSuccess('Email успешно отправлен');
      } else {
        setError(data.message || 'Ошибка при отправке email');
      }
    } catch (err) {
      setError('Произошла ошибка при отправке email');
      console.error('Send email error:', err);
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-6">
      <h2 className="text-xl font-semibold mb-4">Отправка документов по email</h2>
      
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4 flex items-center">
          <FiAlertTriangle className="mr-2" />
          {error}
        </div>
      )}
      
      {success && (
        <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4 flex items-center">
          <FiCheck className="mr-2" />
          {success}
        </div>
      )}
      
      <div className="mb-4">
        <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="email">
          Email получателя
        </label>
        <input
          className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
          id="email"
          type="email"
          value={clientEmail}
          disabled
        />
      </div>
      
      <div className="mb-4">
        <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="subject">
          Тема письма
        </label>
        <input
          className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
          id="subject"
          type="text"
          value={emailSubject}
          onChange={(e) => setEmailSubject(e.target.value)}
        />
      </div>
      
      <div className="mb-6">
        <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="body">
          Текст письма
        </label>
        <textarea
          className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
          id="body"
          rows={6}
          value={emailBody}
          onChange={(e) => setEmailBody(e.target.value)}
        />
      </div>
      
      {documentUrl && (
        <div className="mb-4 p-3 bg-gray-100 rounded">
          <p className="text-sm">
            <span className="font-semibold">Вложение:</span> {documentType === 'contract' ? 'Договор аренды' : documentType === 'invoice' ? 'Счет на оплату' : 'Документ'}
          </p>
        </div>
      )}
      
      <div className="flex items-center justify-between">
        <button
          onClick={handleSendEmail}
          className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline flex items-center"
          disabled={sending || !clientEmail}
        >
          <FiMail className="mr-2" />
          {sending ? 'Отправка...' : 'Отправить email'}
        </button>
      </div>
    </div>
  );
}
