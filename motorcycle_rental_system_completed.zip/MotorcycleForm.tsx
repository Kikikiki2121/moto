'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';

type MotorcycleFormProps = {
  motorcycleId?: number;
  isEditMode?: boolean;
};

type MotorcycleFormData = {
  brand: string;
  model: string;
  license_plate: string;
  year?: number;
  color?: string;
  daily_rate: number;
  weekly_rate: number;
  monthly_rate: number;
  deposit_amount: number;
  status: 'available' | 'rented' | 'maintenance' | 'reserved';
  notes?: string;
};

export default function MotorcycleForm({ motorcycleId, isEditMode = false }: MotorcycleFormProps) {
  const [formData, setFormData] = useState<MotorcycleFormData>({
    brand: '',
    model: '',
    license_plate: '',
    year: undefined,
    color: '',
    daily_rate: 0,
    weekly_rate: 0,
    monthly_rate: 0,
    deposit_amount: 0,
    status: 'available',
    notes: ''
  });
  
  const [loading, setLoading] = useState(isEditMode);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const router = useRouter();

  useEffect(() => {
    if (isEditMode && motorcycleId) {
      fetchMotorcycle();
    }
  }, [isEditMode, motorcycleId]);

  const fetchMotorcycle = async () => {
    try {
      const response = await fetch(`/api/motorcycles/${motorcycleId}`);
      const data = await response.json();

      if (data.success && data.motorcycle) {
        setFormData({
          brand: data.motorcycle.brand,
          model: data.motorcycle.model,
          license_plate: data.motorcycle.license_plate,
          year: data.motorcycle.year,
          color: data.motorcycle.color || '',
          daily_rate: data.motorcycle.daily_rate,
          weekly_rate: data.motorcycle.weekly_rate,
          monthly_rate: data.motorcycle.monthly_rate,
          deposit_amount: data.motorcycle.deposit_amount,
          status: data.motorcycle.status,
          notes: data.motorcycle.notes || ''
        });
      } else {
        setError(data.message || 'Не удалось загрузить данные мотоцикла');
      }
    } catch (err) {
      setError('Ошибка при загрузке данных');
      console.error('Fetch motorcycle error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target as HTMLInputElement;
    
    setFormData(prev => ({
      ...prev,
      [name]: type === 'number' ? (value ? parseFloat(value) : 0) : value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setSubmitting(true);

    try {
      const url = isEditMode 
        ? `/api/motorcycles/${motorcycleId}` 
        : '/api/motorcycles';
      
      const method = isEditMode ? 'PUT' : 'POST';
      
      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (data.success) {
        setSuccess(data.message || 'Операция выполнена успешно');
        
        if (!isEditMode) {
          // Clear form after successful creation
          setFormData({
            brand: '',
            model: '',
            license_plate: '',
            year: undefined,
            color: '',
            daily_rate: 0,
            weekly_rate: 0,
            monthly_rate: 0,
            deposit_amount: 0,
            status: 'available',
            notes: ''
          });
        }
        
        // Redirect after a short delay
        setTimeout(() => {
          router.push('/motorcycles');
        }, 2000);
      } else {
        setError(data.message || 'Произошла ошибка');
      }
    } catch (err) {
      setError('Произошла ошибка при отправке данных');
      console.error('Submit error:', err);
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return <div className="text-center p-8">Загрузка...</div>;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">
        {isEditMode ? 'Редактирование мотоцикла' : 'Добавление нового мотоцикла'}
      </h1>
      
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}
      
      {success && (
        <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
          {success}
        </div>
      )}
      
      <form onSubmit={handleSubmit} className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="brand">
              Марка *
            </label>
            <input
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              id="brand"
              type="text"
              name="brand"
              value={formData.brand}
              onChange={handleChange}
              required
            />
          </div>
          
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="model">
              Модель *
            </label>
            <input
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              id="model"
              type="text"
              name="model"
              value={formData.model}
              onChange={handleChange}
              required
            />
          </div>
          
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="license_plate">
              Номер *
            </label>
            <input
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              id="license_plate"
              type="text"
              name="license_plate"
              value={formData.license_plate}
              onChange={handleChange}
              required
            />
          </div>
          
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="year">
              Год выпуска
            </label>
            <input
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              id="year"
              type="number"
              name="year"
              value={formData.year || ''}
              onChange={handleChange}
              min="1900"
              max={new Date().getFullYear()}
            />
          </div>
          
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="color">
              Цвет
            </label>
            <input
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              id="color"
              type="text"
              name="color"
              value={formData.color || ''}
              onChange={handleChange}
            />
          </div>
          
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="status">
              Статус *
            </label>
            <select
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              id="status"
              name="status"
              value={formData.status}
              onChange={handleChange}
              required
            >
              <option value="available">Доступен</option>
              <option value="maintenance">На обслуживании</option>
              <option value="reserved">Зарезервирован</option>
              {isEditMode && <option value="rented">В аренде</option>}
            </select>
          </div>
          
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="daily_rate">
              Дневная ставка (₽) *
            </label>
            <input
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              id="daily_rate"
              type="number"
              name="daily_rate"
              value={formData.daily_rate}
              onChange={handleChange}
              min="0"
              step="100"
              required
            />
          </div>
          
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="weekly_rate">
              Недельная ставка (₽) *
            </label>
            <input
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              id="weekly_rate"
              type="number"
              name="weekly_rate"
              value={formData.weekly_rate}
              onChange={handleChange}
              min="0"
              step="100"
              required
            />
          </div>
          
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="monthly_rate">
              Месячная ставка (₽) *
            </label>
            <input
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              id="monthly_rate"
              type="number"
              name="monthly_rate"
              value={formData.monthly_rate}
              onChange={handleChange}
              min="0"
              step="100"
              required
            />
          </div>
          
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="deposit_amount">
              Сумма депозита (₽) *
            </label>
            <input
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              id="deposit_amount"
              type="number"
              name="deposit_amount"
              value={formData.deposit_amount}
              onChange={handleChange}
              min="0"
              step="1000"
              required
            />
          </div>
        </div>
        
        <div className="mb-6">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="notes">
            Примечания
          </label>
          <textarea
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            id="notes"
            name="notes"
            value={formData.notes || ''}
            onChange={handleChange}
            rows={3}
          />
        </div>
        
        <div className="flex items-center justify-between">
          <button
            className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
            type="submit"
            disabled={submitting}
          >
            {submitting ? 'Обработка...' : (isEditMode ? 'Сохранить изменения' : 'Добавить мотоцикл')}
          </button>
          <button
            className="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
            type="button"
            onClick={() => router.push('/motorcycles')}
          >
            Отмена
          </button>
        </div>
      </form>
    </div>
  );
}
