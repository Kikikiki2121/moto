'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';

type RentalListProps = {
  initialRentals?: any[];
};

type Rental = {
  id: number;
  motorcycle_id: number;
  client_id: number;
  start_date: string;
  end_date: string;
  actual_return_date: string | null;
  rental_type: 'daily' | 'weekly' | 'monthly';
  rental_rate: number;
  total_amount: number;
  deposit_amount: number;
  deposit_returned: boolean;
  status: 'active' | 'completed' | 'overdue' | 'cancelled';
  contract_number: string;
  notes: string | null;
  created_at: string;
  updated_at: string;
  motorcycle?: any;
  client?: any;
};

export default function RentalList({ initialRentals }: RentalListProps) {
  const [rentals, setRentals] = useState<Rental[]>(initialRentals || []);
  const [loading, setLoading] = useState(!initialRentals);
  const [error, setError] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('');
  const router = useRouter();

  useEffect(() => {
    if (!initialRentals) {
      fetchRentals();
    }
  }, [initialRentals]);

  const fetchRentals = async (filters = {}) => {
    setLoading(true);
    setError('');

    try {
      let url = '/api/rentals?include_motorcycle=true&include_client=true';
      const params = new URLSearchParams();
      
      if (searchTerm) {
        params.append('search', searchTerm);
      }
      
      if (statusFilter) {
        params.append('status', statusFilter);
      }
      
      // Add any additional filters
      Object.entries(filters).forEach(([key, value]) => {
        if (value) {
          params.append(key, value as string);
        }
      });
      
      if (params.toString()) {
        url += `&${params.toString()}`;
      }

      const response = await fetch(url);
      const data = await response.json();

      if (data.success) {
        setRentals(data.rentals || []);
      } else {
        setError(data.message || 'Не удалось загрузить список аренд');
      }
    } catch (err) {
      setError('Ошибка при загрузке данных');
      console.error('Fetch rentals error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    fetchRentals();
  };

  const handleStatusChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setStatusFilter(e.target.value);
    fetchRentals({ status: e.target.value });
  };

  const handleCancelRental = async (id: number) => {
    if (!confirm('Вы уверены, что хотите отменить эту аренду?')) {
      return;
    }

    try {
      const response = await fetch(`/api/rentals/${id}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ action: 'cancel' }),
      });

      const data = await response.json();

      if (data.success) {
        // Update rental in list
        setRentals(rentals.map(rental => 
          rental.id === id ? { ...rental, status: 'cancelled' } : rental
        ));
      } else {
        setError(data.message || 'Не удалось отменить аренду');
      }
    } catch (err) {
      setError('Ошибка при отмене аренды');
      console.error('Cancel rental error:', err);
    }
  };

  // Status display mapping
  const statusDisplay = {
    active: 'Активна',
    completed: 'Завершена',
    overdue: 'Просрочена',
    cancelled: 'Отменена'
  };

  // Status color mapping
  const statusColor = {
    active: 'bg-blue-100 text-blue-800',
    completed: 'bg-green-100 text-green-800',
    overdue: 'bg-red-100 text-red-800',
    cancelled: 'bg-gray-100 text-gray-800'
  };

  if (loading && !rentals.length) {
    return <div className="text-center p-8">Загрузка...</div>;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">Управление арендами</h1>

      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}

      <div className="flex flex-col md:flex-row justify-between mb-6 gap-4">
        <form onSubmit={handleSearch} className="flex gap-2">
          <input
            type="text"
            placeholder="Поиск по номеру договора"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="border rounded px-3 py-2 w-full md:w-64"
          />
          <button
            type="submit"
            className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded"
          >
            Поиск
          </button>
        </form>

        <div className="flex gap-2">
          <select
            value={statusFilter}
            onChange={handleStatusChange}
            className="border rounded px-3 py-2"
          >
            <option value="">Все статусы</option>
            <option value="active">Активные</option>
            <option value="completed">Завершенные</option>
            <option value="overdue">Просроченные</option>
            <option value="cancelled">Отмененные</option>
          </select>

          <button
            onClick={() => router.push('/rentals/new')}
            className="bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 rounded"
          >
            Создать аренду
          </button>
        </div>
      </div>

      {rentals.length === 0 ? (
        <div className="text-center p-8 bg-gray-50 rounded">
          Аренды не найдены
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="min-w-full bg-white border border-gray-200">
            <thead>
              <tr>
                <th className="py-2 px-4 border-b">№ договора</th>
                <th className="py-2 px-4 border-b">Мотоцикл</th>
                <th className="py-2 px-4 border-b">Клиент</th>
                <th className="py-2 px-4 border-b">Период</th>
                <th className="py-2 px-4 border-b">Сумма</th>
                <th className="py-2 px-4 border-b">Статус</th>
                <th className="py-2 px-4 border-b">Действия</th>
              </tr>
            </thead>
            <tbody>
              {rentals.map(rental => (
                <tr key={rental.id} className="hover:bg-gray-50">
                  <td className="py-2 px-4 border-b">{rental.contract_number}</td>
                  <td className="py-2 px-4 border-b">
                    {rental.motorcycle ? 
                      `${rental.motorcycle.brand} ${rental.motorcycle.model}` : 
                      `ID: ${rental.motorcycle_id}`}
                  </td>
                  <td className="py-2 px-4 border-b">
                    {rental.client ? 
                      rental.client.full_name : 
                      `ID: ${rental.client_id}`}
                  </td>
                  <td className="py-2 px-4 border-b">
                    {new Date(rental.start_date).toLocaleDateString()} - {new Date(rental.end_date).toLocaleDateString()}
                  </td>
                  <td className="py-2 px-4 border-b">{rental.total_amount} ₽</td>
                  <td className="py-2 px-4 border-b">
                    <span className={`px-2 py-1 rounded-full text-xs ${statusColor[rental.status]}`}>
                      {statusDisplay[rental.status]}
                    </span>
                  </td>
                  <td className="py-2 px-4 border-b">
                    <div className="flex space-x-2">
                      <button
                        onClick={() => router.push(`/rentals/${rental.id}`)}
                        className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-1 px-2 rounded text-sm"
                      >
                        Просмотр
                      </button>
                      <button
                        onClick={() => router.push(`/rentals/${rental.id}/contract`)}
                        className="bg-purple-500 hover:bg-purple-600 text-white font-bold py-1 px-2 rounded text-sm"
                      >
                        Договор
                      </button>
                      {rental.status === 'active' && (
                        <>
                          <button
                            onClick={() => router.push(`/rentals/${rental.id}/complete`)}
                            className="bg-green-500 hover:bg-green-600 text-white font-bold py-1 px-2 rounded text-sm"
                          >
                            Завершить
                          </button>
                          <button
                            onClick={() => handleCancelRental(rental.id)}
                            className="bg-red-500 hover:bg-red-600 text-white font-bold py-1 px-2 rounded text-sm"
                          >
                            Отменить
                          </button>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
