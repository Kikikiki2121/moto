'use client';

import { useState, useRef } from 'react';
import { FiUpload, FiFile, FiTrash2, FiDownload } from 'react-icons/fi';

interface DocumentUploadProps {
  relatedTo: 'client' | 'rental';
  relatedId: number;
  documentType: 'passport' | 'driver_license' | 'contract' | 'invoice' | 'other';
  onUploadSuccess?: (documentId: number, filePath: string) => void;
  existingDocuments?: {
    id: number;
    file_name: string;
    file_path: string;
    created_at: string;
  }[];
}

export default function DocumentUpload({
  relatedTo,
  relatedId,
  documentType,
  onUploadSuccess,
  existingDocuments = []
}: DocumentUploadProps) {
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [documents, setDocuments] = useState(existingDocuments);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setUploading(true);
    setError('');
    setSuccess('');

    const formData = new FormData();
    formData.append('file', files[0]);
    formData.append('relatedTo', relatedTo);
    formData.append('relatedId', relatedId.toString());
    formData.append('documentType', documentType);

    try {
      const response = await fetch('/api/documents/upload', {
        method: 'POST',
        body: formData,
      });

      const data = await response.json();

      if (data.success) {
        setSuccess('Документ успешно загружен');
        setDocuments(prev => [...prev, {
          id: data.document.id,
          file_name: data.document.file_name,
          file_path: data.document.file_path,
          created_at: data.document.created_at
        }]);

        if (onUploadSuccess) {
          onUploadSuccess(data.document.id, data.document.file_path);
        }
      } else {
        setError(data.message || 'Ошибка при загрузке документа');
      }
    } catch (err) {
      setError('Произошла ошибка при загрузке файла');
      console.error('Upload error:', err);
    } finally {
      setUploading(false);
      // Reset file input
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleDelete = async (documentId: number) => {
    if (!confirm('Вы уверены, что хотите удалить этот документ?')) {
      return;
    }

    try {
      const response = await fetch(`/api/documents/${documentId}`, {
        method: 'DELETE',
      });

      const data = await response.json();

      if (data.success) {
        setSuccess('Документ успешно удален');
        setDocuments(prev => prev.filter(doc => doc.id !== documentId));
      } else {
        setError(data.message || 'Ошибка при удалении документа');
      }
    } catch (err) {
      setError('Произошла ошибка при удалении документа');
      console.error('Delete error:', err);
    }
  };

  const handleDownload = (filePath: string, fileName: string) => {
    window.open(`/api/documents/download?path=${encodeURIComponent(filePath)}`, '_blank');
  };

  const getDocumentTypeLabel = () => {
    switch (documentType) {
      case 'passport': return 'паспорта';
      case 'driver_license': return 'водительского удостоверения';
      case 'contract': return 'договора';
      case 'invoice': return 'счета';
      case 'other': return 'документа';
      default: return 'документа';
    }
  };

  return (
    <div className="mb-6">
      <h3 className="text-lg font-semibold mb-3">Загрузка {getDocumentTypeLabel()}</h3>
      
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}
      
      {success && (
        <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
          {success}
        </div>
      )}
      
      <div className="flex items-center mb-4">
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          className="hidden"
          accept=".pdf,.jpg,.jpeg,.png"
        />
        <button
          onClick={() => fileInputRef.current?.click()}
          className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline flex items-center"
          disabled={uploading}
        >
          <FiUpload className="mr-2" />
          {uploading ? 'Загрузка...' : 'Загрузить файл'}
        </button>
        <span className="ml-3 text-sm text-gray-600">
          Поддерживаемые форматы: PDF, JPG, PNG
        </span>
      </div>
      
      {documents.length > 0 && (
        <div className="mt-4">
          <h4 className="font-medium mb-2">Загруженные документы:</h4>
          <div className="bg-gray-50 rounded-md p-3">
            {documents.map(doc => (
              <div key={doc.id} className="flex items-center justify-between py-2 border-b border-gray-200 last:border-b-0">
                <div className="flex items-center">
                  <FiFile className="text-gray-500 mr-2" />
                  <span className="text-sm">{doc.file_name}</span>
                </div>
                <div className="flex items-center">
                  <span className="text-xs text-gray-500 mr-4">
                    {new Date(doc.created_at).toLocaleDateString()}
                  </span>
                  <button
                    onClick={() => handleDownload(doc.file_path, doc.file_name)}
                    className="text-blue-500 hover:text-blue-700 mr-2"
                    title="Скачать"
                  >
                    <FiDownload />
                  </button>
                  <button
                    onClick={() => handleDelete(doc.id)}
                    className="text-red-500 hover:text-red-700"
                    title="Удалить"
                  >
                    <FiTrash2 />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
