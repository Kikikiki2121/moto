'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';

type Motorcycle = {
  id: number;
  brand: string;
  model: string;
  license_plate: string;
  year?: number;
  color?: string;
  daily_rate: number;
  weekly_rate: number;
  monthly_rate: number;
  deposit_amount: number;
  status: 'available' | 'rented' | 'maintenance' | 'reserved';
  notes?: string;
  created_at: string;
  updated_at: string;
};

type MotorcycleListProps = {
  initialMotorcycles?: Motorcycle[];
};

export default function MotorcycleList({ initialMotorcycles }: MotorcycleListProps) {
  const [motorcycles, setMotorcycles] = useState<Motorcycle[]>(initialMotorcycles || []);
  const [loading, setLoading] = useState(!initialMotorcycles);
  const [error, setError] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('');
  const router = useRouter();

  useEffect(() => {
    if (!initialMotorcycles) {
      fetchMotorcycles();
    }
  }, [initialMotorcycles]);

  const fetchMotorcycles = async (filters = {}) => {
    setLoading(true);
    setError('');

    try {
      let url = '/api/motorcycles';
      const params = new URLSearchParams();
      
      if (searchTerm) {
        params.append('search', searchTerm);
      }
      
      if (statusFilter) {
        params.append('status', statusFilter);
      }
      
      // Add any additional filters
      Object.entries(filters).forEach(([key, value]) => {
        if (value) {
          params.append(key, value as string);
        }
      });
      
      if (params.toString()) {
        url += `?${params.toString()}`;
      }

      const response = await fetch(url);
      const data = await response.json();

      if (data.success) {
        setMotorcycles(data.motorcycles || []);
      } else {
        setError(data.message || 'Не удалось загрузить список мотоциклов');
      }
    } catch (err) {
      setError('Ошибка при загрузке данных');
      console.error('Fetch motorcycles error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    fetchMotorcycles();
  };

  const handleStatusChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setStatusFilter(e.target.value);
    fetchMotorcycles({ status: e.target.value });
  };

  const handleDeleteMotorcycle = async (id: number) => {
    if (!confirm('Вы уверены, что хотите удалить этот мотоцикл?')) {
      return;
    }

    try {
      const response = await fetch(`/api/motorcycles/${id}`, {
        method: 'DELETE',
      });

      const data = await response.json();

      if (data.success) {
        // Remove motorcycle from list
        setMotorcycles(motorcycles.filter(motorcycle => motorcycle.id !== id));
      } else {
        setError(data.message || 'Не удалось удалить мотоцикл');
      }
    } catch (err) {
      setError('Ошибка при удалении мотоцикла');
      console.error('Delete motorcycle error:', err);
    }
  };

  // Status display mapping
  const statusDisplay = {
    available: 'Доступен',
    rented: 'В аренде',
    maintenance: 'На обслуживании',
    reserved: 'Зарезервирован'
  };

  // Status color mapping
  const statusColor = {
    available: 'bg-green-100 text-green-800',
    rented: 'bg-blue-100 text-blue-800',
    maintenance: 'bg-yellow-100 text-yellow-800',
    reserved: 'bg-purple-100 text-purple-800'
  };

  if (loading && !motorcycles.length) {
    return <div className="text-center p-8">Загрузка...</div>;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">Управление мотоциклами</h1>

      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}

      <div className="flex flex-col md:flex-row justify-between mb-6 gap-4">
        <form onSubmit={handleSearch} className="flex gap-2">
          <input
            type="text"
            placeholder="Поиск по марке, модели или номеру"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="border rounded px-3 py-2 w-full md:w-64"
          />
          <button
            type="submit"
            className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded"
          >
            Поиск
          </button>
        </form>

        <div className="flex gap-2">
          <select
            value={statusFilter}
            onChange={handleStatusChange}
            className="border rounded px-3 py-2"
          >
            <option value="">Все статусы</option>
            <option value="available">Доступен</option>
            <option value="rented">В аренде</option>
            <option value="maintenance">На обслуживании</option>
            <option value="reserved">Зарезервирован</option>
          </select>

          <button
            onClick={() => router.push('/motorcycles/new')}
            className="bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 rounded"
          >
            Добавить мотоцикл
          </button>
        </div>
      </div>

      {motorcycles.length === 0 ? (
        <div className="text-center p-8 bg-gray-50 rounded">
          Мотоциклы не найдены
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="min-w-full bg-white border border-gray-200">
            <thead>
              <tr>
                <th className="py-2 px-4 border-b">ID</th>
                <th className="py-2 px-4 border-b">Марка</th>
                <th className="py-2 px-4 border-b">Модель</th>
                <th className="py-2 px-4 border-b">Номер</th>
                <th className="py-2 px-4 border-b">Год</th>
                <th className="py-2 px-4 border-b">Дневная ставка</th>
                <th className="py-2 px-4 border-b">Статус</th>
                <th className="py-2 px-4 border-b">Действия</th>
              </tr>
            </thead>
            <tbody>
              {motorcycles.map(motorcycle => (
                <tr key={motorcycle.id} className="hover:bg-gray-50">
                  <td className="py-2 px-4 border-b">{motorcycle.id}</td>
                  <td className="py-2 px-4 border-b">{motorcycle.brand}</td>
                  <td className="py-2 px-4 border-b">{motorcycle.model}</td>
                  <td className="py-2 px-4 border-b">{motorcycle.license_plate}</td>
                  <td className="py-2 px-4 border-b">{motorcycle.year || '-'}</td>
                  <td className="py-2 px-4 border-b">{motorcycle.daily_rate} ₽</td>
                  <td className="py-2 px-4 border-b">
                    <span className={`px-2 py-1 rounded-full text-xs ${statusColor[motorcycle.status as keyof typeof statusColor]}`}>
                      {statusDisplay[motorcycle.status as keyof typeof statusDisplay]}
                    </span>
                  </td>
                  <td className="py-2 px-4 border-b">
                    <div className="flex space-x-2">
                      <button
                        onClick={() => router.push(`/motorcycles/${motorcycle.id}`)}
                        className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-1 px-2 rounded text-sm"
                      >
                        Просмотр
                      </button>
                      <button
                        onClick={() => router.push(`/motorcycles/edit/${motorcycle.id}`)}
                        className="bg-yellow-500 hover:bg-yellow-600 text-white font-bold py-1 px-2 rounded text-sm"
                      >
                        Изменить
                      </button>
                      <button
                        onClick={() => handleDeleteMotorcycle(motorcycle.id)}
                        className="bg-red-500 hover:bg-red-600 text-white font-bold py-1 px-2 rounded text-sm"
                        disabled={motorcycle.status === 'rented'}
                      >
                        Удалить
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
