'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';

type MotorcycleDetailProps = {
  motorcycleId: number;
};

type Motorcycle = {
  id: number;
  brand: string;
  model: string;
  license_plate: string;
  year?: number;
  color?: string;
  daily_rate: number;
  weekly_rate: number;
  monthly_rate: number;
  deposit_amount: number;
  status: 'available' | 'rented' | 'maintenance' | 'reserved';
  notes?: string;
  created_at: string;
  updated_at: string;
};

export default function MotorcycleDetail({ motorcycleId }: MotorcycleDetailProps) {
  const [motorcycle, setMotorcycle] = useState<Motorcycle | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const router = useRouter();

  useEffect(() => {
    fetchMotorcycle();
  }, [motorcycleId]);

  const fetchMotorcycle = async () => {
    try {
      const response = await fetch(`/api/motorcycles/${motorcycleId}`);
      const data = await response.json();

      if (data.success && data.motorcycle) {
        setMotorcycle(data.motorcycle);
      } else {
        setError(data.message || 'Не удалось загрузить данные мотоцикла');
      }
    } catch (err) {
      setError('Ошибка при загрузке данных');
      console.error('Fetch motorcycle error:', err);
    } finally {
      setLoading(false);
    }
  };

  // Status display mapping
  const statusDisplay = {
    available: 'Доступен',
    rented: 'В аренде',
    maintenance: 'На обслуживании',
    reserved: 'Зарезервирован'
  };

  // Status color mapping
  const statusColor = {
    available: 'bg-green-100 text-green-800',
    rented: 'bg-blue-100 text-blue-800',
    maintenance: 'bg-yellow-100 text-yellow-800',
    reserved: 'bg-purple-100 text-purple-800'
  };

  if (loading) {
    return <div className="text-center p-8">Загрузка...</div>;
  }

  if (error || !motorcycle) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error || 'Мотоцикл не найден'}
        </div>
        <button
          onClick={() => router.push('/motorcycles')}
          className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
        >
          Вернуться к списку
        </button>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">
          {motorcycle.brand} {motorcycle.model}
        </h1>
        <div className="flex space-x-2">
          <button
            onClick={() => router.push(`/motorcycles/edit/${motorcycle.id}`)}
            className="bg-yellow-500 hover:bg-yellow-600 text-white font-bold py-2 px-4 rounded"
          >
            Редактировать
          </button>
          <button
            onClick={() => router.push('/motorcycles')}
            className="bg-gray-500 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded"
          >
            Назад к списку
          </button>
        </div>
      </div>

      <div className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h2 className="text-xl font-semibold mb-4">Основная информация</h2>
            <div className="space-y-3">
              <div>
                <span className="font-semibold">Статус:</span>{' '}
                <span className={`px-2 py-1 rounded-full text-xs ${statusColor[motorcycle.status]}`}>
                  {statusDisplay[motorcycle.status as keyof typeof statusDisplay]}
                </span>
              </div>
              <div>
                <span className="font-semibold">Номер:</span> {motorcycle.license_plate}
              </div>
              <div>
                <span className="font-semibold">Год выпуска:</span> {motorcycle.year || 'Не указан'}
              </div>
              <div>
                <span className="font-semibold">Цвет:</span> {motorcycle.color || 'Не указан'}
              </div>
            </div>
          </div>

          <div>
            <h2 className="text-xl font-semibold mb-4">Тарифы аренды</h2>
            <div className="space-y-3">
              <div>
                <span className="font-semibold">Дневная ставка:</span> {motorcycle.daily_rate} ₽
              </div>
              <div>
                <span className="font-semibold">Недельная ставка:</span> {motorcycle.weekly_rate} ₽
              </div>
              <div>
                <span className="font-semibold">Месячная ставка:</span> {motorcycle.monthly_rate} ₽
              </div>
              <div>
                <span className="font-semibold">Депозит:</span> {motorcycle.deposit_amount} ₽
              </div>
            </div>
          </div>
        </div>

        {motorcycle.notes && (
          <div className="mt-6">
            <h2 className="text-xl font-semibold mb-2">Примечания</h2>
            <p className="bg-gray-50 p-3 rounded">{motorcycle.notes}</p>
          </div>
        )}

        <div className="mt-6 text-sm text-gray-500">
          <div>Создан: {new Date(motorcycle.created_at).toLocaleString()}</div>
          <div>Обновлен: {new Date(motorcycle.updated_at).toLocaleString()}</div>
        </div>
      </div>

      {motorcycle.status === 'available' && (
        <div className="mt-4">
          <button
            onClick={() => router.push(`/rentals/new?motorcycle_id=${motorcycle.id}`)}
            className="bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 rounded"
          >
            Создать аренду
          </button>
        </div>
      )}
    </div>
  );
}
