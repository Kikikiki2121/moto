'use client';

import { useState } from 'react';
import { FiFileText, FiDownload, FiMail } from 'react-icons/fi';

interface ContractGeneratorProps {
  rentalId: number;
  contractNumber: string;
  clientName: string;
  motorcycleName: string;
}

export default function ContractGenerator({
  rentalId,
  contractNumber,
  clientName,
  motorcycleName
}: ContractGeneratorProps) {
  const [generating, setGenerating] = useState(false);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [contractUrl, setContractUrl] = useState<string | null>(null);

  const handleGenerateContract = async () => {
    setGenerating(true);
    setError('');
    setSuccess('');
    setContractUrl(null);

    try {
      const response = await fetch(`/api/contracts/generate`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          rentalId,
          type: 'contract'
        }),
      });

      const data = await response.json();

      if (data.success) {
        setSuccess('Договор успешно сгенерирован');
        setContractUrl(data.documentUrl);
      } else {
        setError(data.message || 'Ошибка при генерации договора');
      }
    } catch (err) {
      setError('Произошла ошибка при генерации договора');
      console.error('Generate contract error:', err);
    } finally {
      setGenerating(false);
    }
  };

  const handleGenerateInvoice = async () => {
    setGenerating(true);
    setError('');
    setSuccess('');
    setContractUrl(null);

    try {
      const response = await fetch(`/api/contracts/generate`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          rentalId,
          type: 'invoice'
        }),
      });

      const data = await response.json();

      if (data.success) {
        setSuccess('Счет успешно сгенерирован');
        setContractUrl(data.documentUrl);
      } else {
        setError(data.message || 'Ошибка при генерации счета');
      }
    } catch (err) {
      setError('Произошла ошибка при генерации счета');
      console.error('Generate invoice error:', err);
    } finally {
      setGenerating(false);
    }
  };

  const handleSendEmail = async () => {
    if (!contractUrl) {
      setError('Сначала необходимо сгенерировать документ');
      return;
    }

    setSending(true);
    setError('');
    setSuccess('');

    try {
      const response = await fetch(`/api/email/send`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          rentalId,
          documentUrl: contractUrl,
          documentType: contractUrl.includes('invoice') ? 'invoice' : 'contract'
        }),
      });

      const data = await response.json();

      if (data.success) {
        setSuccess('Документ успешно отправлен по email');
      } else {
        setError(data.message || 'Ошибка при отправке email');
      }
    } catch (err) {
      setError('Произошла ошибка при отправке email');
      console.error('Send email error:', err);
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-6">
      <h2 className="text-xl font-semibold mb-4">Документы аренды</h2>
      
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}
      
      {success && (
        <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
          {success}
        </div>
      )}
      
      <div className="mb-4">
        <p className="mb-2">
          <span className="font-semibold">Номер договора:</span> {contractNumber}
        </p>
        <p className="mb-2">
          <span className="font-semibold">Клиент:</span> {clientName}
        </p>
        <p className="mb-2">
          <span className="font-semibold">Мотоцикл:</span> {motorcycleName}
        </p>
      </div>
      
      <div className="flex flex-wrap gap-4 mb-6">
        <button
          onClick={handleGenerateContract}
          className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline flex items-center"
          disabled={generating}
        >
          <FiFileText className="mr-2" />
          {generating ? 'Генерация...' : 'Сгенерировать договор'}
        </button>
        
        <button
          onClick={handleGenerateInvoice}
          className="bg-purple-500 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline flex items-center"
          disabled={generating}
        >
          <FiFileText className="mr-2" />
          {generating ? 'Генерация...' : 'Сгенерировать счет'}
        </button>
        
        {contractUrl && (
          <>
            <a
              href={contractUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline flex items-center"
            >
              <FiDownload className="mr-2" />
              Скачать документ
            </a>
            
            <button
              onClick={handleSendEmail}
              className="bg-yellow-500 hover:bg-yellow-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline flex items-center"
              disabled={sending}
            >
              <FiMail className="mr-2" />
              {sending ? 'Отправка...' : 'Отправить по email'}
            </button>
          </>
        )}
      </div>
      
      <div className="border-t border-gray-200 pt-4">
        <h3 className="font-semibold mb-2">История документов</h3>
        <div className="bg-gray-50 p-3 rounded">
          {/* This would be populated with actual document history */}
          <p className="text-gray-500 italic">История документов будет отображаться здесь</p>
        </div>
      </div>
    </div>
  );
}
