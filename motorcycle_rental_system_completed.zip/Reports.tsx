'use client';

import { useState, useEffect } from 'react';
import { FiDownload, FiFilter, FiPieChart } from 'react-icons/fi';
import { Chart as ChartJS, ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement, Title } from 'chart.js';
import { Bar } from 'react-chartjs-2';

ChartJS.register(ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement, Title);

type ReportType = 'revenue' | 'rentals' | 'deposits' | 'motorcycles';

export default function Reports() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [reportType, setReportType] = useState<ReportType>('revenue');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [reportData, setReportData] = useState<any>(null);

  useEffect(() => {
    // Set default date range to current month
    const now = new Date();
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
    const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    
    setStartDate(firstDay.toISOString().split('T')[0]);
    setEndDate(lastDay.toISOString().split('T')[0]);
  }, []);

  const generateReport = async () => {
    setLoading(true);
    setError('');
    setReportData(null);

    try {
      const response = await fetch(
        `/api/reports?type=${reportType}&startDate=${startDate}&endDate=${endDate}`
      );
      
      const data = await response.json();

      if (data.success) {
        setReportData(data.data);
      } else {
        setError(data.message || 'Ошибка при генерации отчета');
      }
    } catch (err) {
      setError('Произошла ошибка при получении данных отчета');
      console.error('Generate report error:', err);
    } finally {
      setLoading(false);
    }
  };

  const exportToCSV = () => {
    if (!reportData) return;
    
    let csvContent = 'data:text/csv;charset=utf-8,';
    
    // Add headers and data based on report type
    if (reportType === 'revenue' && reportData.monthly) {
      csvContent += 'Месяц,Доход,Количество аренд\n';
      reportData.monthly.forEach((item: any) => {
        csvContent += `${item.month},${item.revenue},${item.rental_count}\n`;
      });
      csvContent += `Итого,${reportData.total.revenue},${reportData.total.rentalCount}\n`;
    } else if (reportType === 'rentals') {
      csvContent += 'Статус,Количество,Средняя длительность (дни)\n';
      reportData.byStatus.forEach((item: any) => {
        csvContent += `${item.status},${item.count},${item.avg_duration.toFixed(2)}\n`;
      });
      csvContent += `\nТип аренды,Количество\n`;
      reportData.byType.forEach((item: any) => {
        csvContent += `${item.rental_type},${item.count}\n`;
      });
    } else if (reportType === 'deposits') {
      csvContent += 'Показатель,Значение\n';
      csvContent += `Всего депозитов,${reportData.summary.total_deposits}\n`;
      csvContent += `Возвращено депозитов,${reportData.summary.returned_deposits}\n`;
      csvContent += `Удержано депозитов,${reportData.summary.held_deposits}\n`;
      csvContent += `Сумма удержаний,${reportData.summary.deduction_amount}\n`;
      csvContent += `\nПричина удержания,Количество,Сумма\n`;
      reportData.deductionReasons.forEach((item: any) => {
        csvContent += `${item.reason || 'Не указана'},${item.count},${item.amount}\n`;
      });
    } else if (reportType === 'motorcycles') {
      csvContent += 'Мотоцикл,Номер,Количество аренд,Доход,Дней в аренде\n';
      reportData.motorcycles.forEach((item: any) => {
        csvContent += `${item.brand} ${item.model},${item.license_plate},${item.rental_count},${item.revenue},${item.total_days_rented?.toFixed(2) || 0}\n`;
      });
    }
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `report_${reportType}_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const renderReportContent = () => {
    if (!reportData) return null;
    
    switch (reportType) {
      case 'revenue':
        return renderRevenueReport();
      case 'rentals':
        return renderRentalsReport();
      case 'deposits':
        return renderDepositsReport();
      case 'motorcycles':
        return renderMotorcyclesReport();
      default:
        return <p>Выберите тип отчета</p>;
    }
  };

  const renderRevenueReport = () => {
    if (!reportData || !reportData.monthly) return null;
    
    const chartData = {
      labels: reportData.monthly.map((item: any) => item.month),
      datasets: [
        {
          label: 'Доход (₽)',
          data: reportData.monthly.map((item: any) => item.revenue),
          backgroundColor: 'rgba(75, 192, 192, 0.6)',
          borderColor: 'rgb(75, 192, 192)',
          borderWidth: 1
        }
      ]
    };

    const chartOptions = {
      responsive: true,
      plugins: {
        legend: {
          position: 'top' as const,
        },
        title: {
          display: true,
          text: 'Доход по месяцам'
        }
      }
    };

    return (
      <div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="bg-white rounded-lg shadow-md p-4">
            <h3 className="text-lg font-semibold mb-2">Общий доход</h3>
            <p className="text-2xl font-bold">{reportData.total.revenue.toFixed(2)} ₽</p>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-4">
            <h3 className="text-lg font-semibold mb-2">Количество аренд</h3>
            <p className="text-2xl font-bold">{reportData.total.rentalCount}</p>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-4">
            <h3 className="text-lg font-semibold mb-2">Средний доход с аренды</h3>
            <p className="text-2xl font-bold">{reportData.total.averageRevenue.toFixed(2)} ₽</p>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <h3 className="text-lg font-semibold mb-4">Доход по месяцам</h3>
          <div className="h-80">
            <Bar data={chartData} options={chartOptions} />
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold mb-4">Детализация по месяцам</h3>
          <div className="overflow-x-auto">
            <table className="min-w-full bg-white">
              <thead>
                <tr>
                  <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                    Месяц
                  </th>
                  <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                    Доход
                  </th>
                  <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                    Количество аренд
                  </th>
                  <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                    Средний доход
                  </th>
                </tr>
              </thead>
              <tbody>
                {reportData.monthly.map((item: any, index: number) => (
                  <tr key={index} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                    <td className="py-2 px-4 border-b border-gray-200 text-sm">{item.month}</td>
                    <td className="py-2 px-4 border-b border-gray-200 text-sm">{item.revenue.toFixed(2)} ₽</td>
                    <td className="py-2 px-4 border-b border-gray-200 text-sm">{item.rental_count}</td>
                    <td className="py-2 px-4 border-b border-gray-200 text-sm">
                      {(item.revenue / item.rental_count).toFixed(2)} ₽
                    </td>
                  </tr>
                ))}
                <tr className="bg-gray-100 font-semibold">
                  <td className="py-2 px-4 border-b border-gray-200 text-sm">Итого</td>
                  <td className="py-2 px-4 border-b border-gray-200 text-sm">{reportData.total.revenue.toFixed(2)} ₽</td>
                  <td className="py-2 px-4 border-b border-gray-200 text-sm">{reportData.total.rentalCount}</td>
                  <td className="py-2 px-4 border-b border-gray-200 text-sm">{reportData.total.averageRevenue.toFixed(2)} ₽</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  };

  const renderRentalsReport = () => {
    if (!reportData) return null;
    
    return (
      <div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          <div className="bg-white rounded-lg shadow-md p-4">
            <h3 className="text-lg font-semibold mb-2">Всего аренд</h3>
            <p className="text-2xl font-bold">{reportData.total.count}</p>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-4">
            <h3 className="text-lg font-semibold mb-2">Средняя длительность</h3>
            <p className="text-2xl font-bold">{reportData.total.avgDuration?.toFixed(2) || 0} дней</p>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-lg font-semibold mb-4">Аренды по статусам</h3>
            <div className="overflow-x-auto">
              <table className="min-w-full bg-white">
                <thead>
                  <tr>
                    <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                      Статус
                    </th>
                    <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                      Количество
                    </th>
                    <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                      Средняя длительность (дни)
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {reportData.byStatus.map((item: any, index: number) => (
                    <tr key={index} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                      <td className="py-2 px-4 border-b border-gray-200 text-sm">
                        {item.status === 'active' ? 'Активные' :
                         item.status === 'completed' ? 'Завершенные' :
                         item.status === 'overdue' ? 'Просроченные' :
                         item.status === 'cancelled' ? 'Отмененные' : item.status}
                      </td>
                      <td className="py-2 px-4 border-b border-gray-200 text-sm">{item.count}</td>
                      <td className="py-2 px-4 border-b border-gray-200 text-sm">{item.avg_duration?.toFixed(2) || 0}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-lg font-semibold mb-4">Аренды по типам</h3>
            <div className="overflow-x-auto">
              <table className="min-w-full bg-white">
                <thead>
                  <tr>
                    <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                      Тип аренды
                    </th>
                    <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                      Количество
                    </th>
                    <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                      Процент
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {reportData.byType.map((item: any, index: number) => (
                    <tr key={index} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                      <td className="py-2 px-4 border-b border-gray-200 text-sm">
                        {item.rental_type === 'daily' ? 'Дневная' :
                         item.rental_type === 'weekly' ? 'Недельная' :
                         item.rental_type === 'monthly' ? 'Месячная' : item.rental_type}
                      </td>
                      <td className="py-2 px-4 border-b border-gray-200 text-sm">{item.count}</td>
                      <td className="py-2 px-4 border-b border-gray-200 text-sm">
                        {((item.count / reportData.total.count) * 100).toFixed(2)}%
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderDepositsReport = () => {
    if (!reportData || !reportData.summary) return null;
    
    return (
      <div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="bg-white rounded-lg shadow-md p-4">
            <h3 className="text-lg font-semibold mb-2">Всего депозитов</h3>
            <p className="text-2xl font-bold">{reportData.summary.total_deposits?.toFixed(2) || 0} ₽</p>
            <p className="text-sm text-gray-500">{reportData.summary.total_count} аренд</p>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-4">
            <h3 className="text-lg font-semibold mb-2">Возвращено</h3>
            <p className="text-2xl font-bold">{reportData.summary.returned_deposits?.toFixed(2) || 0} ₽</p>
            <p className="text-sm text-gray-500">{reportData.summary.returned_count} аренд</p>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-4">
            <h3 className="text-lg font-semibold mb-2">Удержано</h3>
            <p className="text-2xl font-bold">{reportData.summary.held_deposits?.toFixed(2) || 0} ₽</p>
            <p className="text-sm text-gray-500">{reportData.summary.held_count} аренд</p>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <h3 className="text-lg font-semibold mb-4">Удержания депозитов</h3>
          <div className="mb-4">
            <p className="font-medium">Общая сумма удержаний: {reportData.summary.deduction_amount?.toFixed(2) || 0} ₽</p>
          </div>
          
          {reportData.deductionReasons && reportData.deductionReasons.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="min-w-full bg-white">
                <thead>
                  <tr>
                    <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                      Причина удержания
                    </th>
                    <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                      Количество
                    </th>
                    <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                      Сумма
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {reportData.deductionReasons.map((item: any, index: number) => (
                    <tr key={index} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                      <td className="py-2 px-4 border-b border-gray-200 text-sm">{item.reason || 'Не указана'}</td>
                      <td className="py-2 px-4 border-b border-gray-200 text-sm">{item.count}</td>
                      <td className="py-2 px-4 border-b border-gray-200 text-sm">{item.amount?.toFixed(2) || 0} ₽</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-gray-500 italic">Нет данных об удержаниях</p>
          )}
        </div>
      </div>
    );
  };

  const renderMotorcyclesReport = () => {
    if (!reportData || !reportData.motorcycles) return null;
    
    return (
      <div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="bg-white rounded-lg shadow-md p-4">
            <h3 className="text-lg font-semibold mb-2">Всего мотоциклов</h3>
            <p className="text-2xl font-bold">{reportData.total.count}</p>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-4">
            <h3 className="text-lg font-semibold mb-2">Всего аренд</h3>
            <p className="text-2xl font-bold">{reportData.total.totalRentals}</p>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-4">
            <h3 className="text-lg font-semibold mb-2">Общий доход</h3>
            <p className="text-2xl font-bold">{reportData.total.totalRevenue?.toFixed(2) || 0} ₽</p>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <h3 className="text-lg font-semibold mb-4">Статистика по мотоциклам</h3>
          <div className="overflow-x-auto">
            <table className="min-w-full bg-white">
              <thead>
                <tr>
                  <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                    Мотоцикл
                  </th>
                  <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                    Номер
                  </th>
                  <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                    Количество аренд
                  </th>
                  <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                    Доход
                  </th>
                  <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                    Дней в аренде
                  </th>
                </tr>
              </thead>
              <tbody>
                {reportData.motorcycles.map((item: any, index: number) => (
                  <tr key={index} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                    <td className="py-2 px-4 border-b border-gray-200 text-sm">{item.brand} {item.model}</td>
                    <td className="py-2 px-4 border-b border-gray-200 text-sm">{item.license_plate}</td>
                    <td className="py-2 px-4 border-b border-gray-200 text-sm">{item.rental_count}</td>
                    <td className="py-2 px-4 border-b border-gray-200 text-sm">{item.revenue?.toFixed(2) || 0} ₽</td>
                    <td className="py-2 px-4 border-b border-gray-200 text-sm">{item.total_days_rented?.toFixed(2) || 0}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold mb-4">Распределение по статусам</h3>
          <div className="overflow-x-auto">
            <table className="min-w-full bg-white">
              <thead>
                <tr>
                  <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                    Статус
                  </th>
                  <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                    Количество
                  </th>
                  <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                    Процент
                  </th>
                </tr>
              </thead>
              <tbody>
                {reportData.statusDistribution.map((item: any, index: number) => (
                  <tr key={index} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                    <td className="py-2 px-4 border-b border-gray-200 text-sm">
                      {item.status === 'available' ? 'Доступен' :
                       item.status === 'rented' ? 'В аренде' :
                       item.status === 'maintenance' ? 'На обслуживании' :
                       item.status === 'reserved' ? 'Зарезервирован' : item.status}
                    </td>
                    <td className="py-2 px-4 border-b border-gray-200 text-sm">{item.count}</td>
                    <td className="py-2 px-4 border-b border-gray-200 text-sm">
                      {((item.count / reportData.total.count) * 100).toFixed(2)}%
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">Отчеты</h1>
      
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}
      
      <div className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-6">
        <div className="flex flex-wrap items-center gap-4 mb-6">
          <div className="flex-1">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="reportType">
              Тип отчета
            </label>
            <select
              id="reportType"
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              value={reportType}
              onChange={(e) => setReportType(e.target.value as ReportType)}
            >
              <option value="revenue">Доходы</option>
              <option value="rentals">Аренды</option>
              <option value="deposits">Депозиты</option>
              <option value="motorcycles">Мотоциклы</option>
            </select>
          </div>
          
          <div className="flex-1">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="startDate">
              Дата начала
            </label>
            <input
              id="startDate"
              type="date"
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
            />
          </div>
          
          <div className="flex-1">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="endDate">
              Дата окончания
            </label>
            <input
              id="endDate"
              type="date"
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
            />
          </div>
          
          <div className="flex items-end">
            <button
              onClick={generateReport}
              className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline flex items-center"
              disabled={loading}
            >
              <FiFilter className="mr-2" />
              {loading ? 'Загрузка...' : 'Сформировать отчет'}
            </button>
          </div>
        </div>
        
        {reportData && (
          <div className="flex justify-end mb-4">
            <button
              onClick={exportToCSV}
              className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline flex items-center"
            >
              <FiDownload className="mr-2" />
              Экспорт в CSV
            </button>
          </div>
        )}
      </div>
      
      {loading ? (
        <div className="text-center p-8">
          <p className="text-gray-600">Формирование отчета...</p>
        </div>
      ) : reportData ? (
        renderReportContent()
      ) : (
        <div className="text-center p-8 bg-white shadow-md rounded">
          <FiPieChart className="mx-auto text-gray-400 text-5xl mb-4" />
          <p className="text-gray-600">Выберите параметры и нажмите "Сформировать отчет"</p>
        </div>
      )}
    </div>
  );
}
